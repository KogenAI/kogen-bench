mod timing;
fn main() {
    eprintln!("{{\"error\":{{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"implement the queue\"}}}}");
    std::process::exit(70);
}
