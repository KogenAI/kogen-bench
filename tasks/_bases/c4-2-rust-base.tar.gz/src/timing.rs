#[allow(dead_code)]
pub fn retry_delay(attempt: u32) -> i64 {
    (100_i64 << (attempt - 1)).min(10000)
}
#[cfg(test)]
mod tests {
    use super::retry_delay;
    #[test]
    fn first_retry() {
        assert_eq!(retry_delay(1), 100);
    }
    #[test]
    fn exponential_retry() {
        assert_eq!(retry_delay(3), 400);
    }
    #[test]
    fn capped_retry() {
        assert_eq!(retry_delay(16), 10000);
    }
}
