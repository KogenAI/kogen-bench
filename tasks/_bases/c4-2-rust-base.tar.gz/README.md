# Durable queue starter

Implement the supplied task contract in this language. The starter deliberately
returns NOT_IMPLEMENTED (exit 70) for every command.

Run `make build` offline, then `./bin/app stats --state ./state`.
`make check` runs the pinned formatting, static-analysis and unit-test tools.
`make test` runs the public unit tests. Runtime files belong under --state.
The toolchains and dependency caches are supplied by the execution environment.
