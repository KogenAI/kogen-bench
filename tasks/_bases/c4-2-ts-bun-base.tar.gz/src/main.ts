console.error(
  JSON.stringify({
    error: { code: 'NOT_IMPLEMENTED', message: 'implement the queue' },
  }),
);
process.exit(70);
