export function retryDelay(attempt: number): number {
  return Math.min(100 * 2 ** (attempt - 1), 10000);
}
