import { expect, test } from 'bun:test';
import { retryDelay } from '../src/timing';

test('first retry', () => expect(retryDelay(1)).toBe(100));
test('exponential retry', () => expect(retryDelay(3)).toBe(400));
test('capped retry', () => expect(retryDelay(16)).toBe(10000));
