# Go base

Build the CLI with `make build`, then run it as `./bin/app COMMAND --root DIR`.
The Go implementation uses only the standard library and builds with the
offline toolchain configured by the Makefile.
