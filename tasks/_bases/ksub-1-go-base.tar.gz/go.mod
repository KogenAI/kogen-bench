module durablequeue

go 1.27.1
