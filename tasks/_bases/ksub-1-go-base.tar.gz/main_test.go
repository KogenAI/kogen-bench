package main

import (
	"encoding/json"
	"reflect"
	"testing"
)

func TestJSONRoundTrip(t *testing.T) {
	type sample struct {
		Name    string `json:"name"`
		Count   int    `json:"count"`
		Enabled bool   `json:"enabled"`
	}
	want := sample{Name: "queue", Count: 3, Enabled: true}

	data, err := json.Marshal(want)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	var got sample
	if err := json.Unmarshal(data, &got); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("round trip = %#v, want %#v", got, want)
	}
}
