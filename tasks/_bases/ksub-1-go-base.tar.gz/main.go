package main

import (
	"encoding/json"
	"fmt"
	"os"
)

func main() {
	message, code := execute(os.Args[1:])
	if code == 0 {
		_, _ = fmt.Fprintln(os.Stdout, message)
		return
	}
	_, _ = fmt.Fprintln(os.Stderr, message)
	os.Exit(code)
}

func execute(_ []string) (string, int) {
	message, _ := json.Marshal(map[string]any{
		"error": map[string]string{
			"code":    "NOT_IMPLEMENTED",
			"message": "command is not implemented",
		},
	})
	return string(message), 70
}
