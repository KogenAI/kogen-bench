package main

func retryDelay(attempt int) int64 {
	delay := int64(100) << (attempt - 1)
	if delay > 10000 {
		return 10000
	}
	return delay
}
