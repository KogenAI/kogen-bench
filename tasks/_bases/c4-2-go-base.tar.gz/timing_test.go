package main

import "testing"

func TestFirstRetry(t *testing.T) {
	if retryDelay(1) != 100 {
		t.Fatal("first retry")
	}
}
func TestExponentialRetry(t *testing.T) {
	if retryDelay(3) != 400 {
		t.Fatal("exponential retry")
	}
}
func TestCappedRetry(t *testing.T) {
	if retryDelay(16) != 10000 {
		t.Fatal("capped retry")
	}
}
