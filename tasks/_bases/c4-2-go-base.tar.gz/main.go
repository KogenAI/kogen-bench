package main

import (
	"fmt"
	"os"
)

func main() {
	fmt.Fprintln(os.Stderr, `{"error":{"code":"NOT_IMPLEMENTED","message":"implement the queue"}}`)
	os.Exit(70)
}
