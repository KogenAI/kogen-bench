import { expect, test } from 'bun:test';
import { validName } from '../src/shared';

test('ordinary name', () => expect(validName('fix-2_a')).toBe(true));
test('empty name', () => expect(validName('')).toBe(false));
test('traversal name', () => expect(validName('../bad')).toBe(false));
