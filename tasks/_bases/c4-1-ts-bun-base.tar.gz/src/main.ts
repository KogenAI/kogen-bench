console.error(
  JSON.stringify({
    error: { code: 'NOT_IMPLEMENTED', message: 'Implement the CLI' },
  }),
);
process.exit(70);
