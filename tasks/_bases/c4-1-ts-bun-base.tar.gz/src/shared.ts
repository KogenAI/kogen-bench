export function validName(s: string): boolean {
  return /^[a-z][a-z0-9_-]{0,39}$/.test(s) && !s.includes('\n');
}
