use std::io::{self, Write};

fn main() {
    let error = serde_json::json!({
        "error": {
            "code": "NOT_IMPLEMENTED",
            "message": "command is not implemented"
        }
    });
    let mut stderr = io::stderr().lock();
    let _ = serde_json::to_writer(&mut stderr, &error);
    let _ = stderr.write_all(b"\n");
    std::process::exit(70);
}
#[cfg(test)]
mod tests {
    fn round_trip(value: serde_json::Value) -> serde_json::Value {
        let encoded = serde_json::to_vec(&value).unwrap();
        serde_json::from_slice(&encoded).unwrap()
    }

    #[test]
    fn nested_json_values_round_trip() {
        let value = serde_json::json!({"items": [1, true, null], "name": "queue"});
        assert_eq!(round_trip(value.clone()), value);
    }

    #[test]
    fn scalar_json_values_round_trip() {
        let value = serde_json::json!([false, 42, null]);
        assert_eq!(round_trip(value.clone()), value);
    }

    #[test]
    fn unicode_json_strings_round_trip() {
        let value = serde_json::json!("résumé 🧪");
        assert_eq!(round_trip(value.clone()), value);
    }
}
