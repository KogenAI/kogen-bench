# Rust base

Build the offline CLI with `make build`; the executable is written to
`bin/app`. Run formatting, lint, and unit checks with `make check`, or just the
unit checks with `make test`.

The base is an intentionally unimplemented starting point. Every invocation
returns a `NOT_IMPLEMENTED` JSON error and exits with status 70.

