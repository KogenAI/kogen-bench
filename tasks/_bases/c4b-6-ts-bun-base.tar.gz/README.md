Bounded supervisor skeleton

Linux only. Run `make build`, `make check`, `make test` offline. The entry point is `./bin/app`.

Optional OS bridge: `bin/launch ERRORFILE CWD CPU_SECONDS MEMORY_BYTES PROGRAM [ARG ...]`
sets its process group, stdin, and resource limits, then execs PROGRAM with the inherited environment. ERRORFILE must be a precreated empty file below your root; on setup/exec failure it writes `system`/`exec` and exits 127. Successful exec leaves it empty. Remove it after use. This helper does not supervise, capture output, validate policy or reap descendants.

`bin/libspawn.so` exports `int runner_spawn(char *const argv[], char *const envp[], int fds[2])`: null-terminated C string-pointer arrays, argv[0] is the absolute launcher path and argv[1] its error file. It returns a child PID (negative errno on failure) and the parent stdout/stderr read FDs. The caller must drain/close FDs and call wait4; this bridge performs only fork, pipe, dup2 and execve. It does not supervise or reap. Child-side calls after the raw fork are async-signal-safe. The helper is optional and identical in all stacks.
