import { expect, test } from 'bun:test';
import { isAbsolute } from 'node:path';

test('placeholder', () => {
  expect(2 + 2).toBe(4);
});
test('absolute path', () => {
  expect(isAbsolute('/usr/bin')).toBe(true);
});
test('base64 padding', () => {
  expect(Buffer.from([0, 255]).toString('base64')).toBe('AP8=');
});
