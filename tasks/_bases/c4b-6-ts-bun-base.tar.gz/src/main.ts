console.error(
  JSON.stringify({
    error: { code: 'NOT_IMPLEMENTED', message: 'not implemented' },
  }),
);
process.exit(70);
