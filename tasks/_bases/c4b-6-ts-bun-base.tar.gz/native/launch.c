#define _GNU_SOURCE
#include <sys/resource.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
static void fail(const char *path, const char *kind) {
    int fd = open(path, O_WRONLY | O_TRUNC);
    if (fd >= 0) { ssize_t n = write(fd, kind, strlen(kind)); (void)n; close(fd); }
    _exit(127);
}
int main(int argc, char **argv) {
    if (argc < 6) return 127;
    const char *error = argv[1];
    struct rlimit cpu = {strtoull(argv[3], NULL, 10), strtoull(argv[3], NULL, 10) + 1};
    struct rlimit mem = {strtoull(argv[4], NULL, 10), strtoull(argv[4], NULL, 10)};
    struct rlimit core = {0, 0};
    int fd = open("/dev/null", O_RDONLY);
    if (fd < 0 || dup2(fd, 0) < 0) fail(error, "system");
    if (fd != 0) close(fd);
    if (setpgid(0, 0) != 0 || chdir(argv[2]) != 0 ||
        setrlimit(RLIMIT_CPU, &cpu) != 0 || setrlimit(RLIMIT_AS, &mem) != 0 ||
        setrlimit(RLIMIT_CORE, &core) != 0) fail(error, "system");
    execv(argv[5], argv + 5);
    fail(error, "exec");
}
