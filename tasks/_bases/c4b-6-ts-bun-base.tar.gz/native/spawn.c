#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
/* Raw spawn bridge for runtimes that do not expose the complete wait status.
 * Caller owns policy, supervision, output draining and all wait4/reaping. */
int runner_spawn(char *const argv[], char *const envp[], int fds[2]) {
    int out[2], err[2];
    if (pipe2(out, O_CLOEXEC) != 0) return -errno;
    if (pipe2(err, O_CLOEXEC) != 0) {
        int e = errno; close(out[0]); close(out[1]); return -e;
    }
    int pid = (int)syscall(SYS_clone, (unsigned long)SIGCHLD, NULL, NULL, NULL, 0);
    if (pid < 0) {
        int e = errno; close(out[0]); close(out[1]); close(err[0]); close(err[1]); return -e;
    }
    if (pid == 0) {
        close(out[0]); close(err[0]);
        if (dup2(out[1], 1) >= 0 && dup2(err[1], 2) >= 0) {
            close(out[1]); close(err[1]);
            execve(argv[0], argv, envp);
        }
        int fd = open(argv[1], O_WRONLY | O_TRUNC);
        if (fd >= 0) { ssize_t n = write(fd, "system", 6); (void)n; close(fd); }
        _exit(127);
    }
    close(out[1]); close(err[1]); fds[0] = out[0]; fds[1] = err[0];
    return pid;
}
