import { expect, test } from 'bun:test';

test('skeleton', () => {
  expect(2 + 2).toBe(4);
});
