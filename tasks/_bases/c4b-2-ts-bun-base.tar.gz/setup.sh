#!/bin/sh
set -eu
if [ ! -d node_modules ]; then cp -R /srv/bh/bench/toolchains/bun-1.4.2/node-template/node_modules .; fi
cp /srv/bh/bench/toolchains/bun-1.4.2/node-template/bun.lock .
