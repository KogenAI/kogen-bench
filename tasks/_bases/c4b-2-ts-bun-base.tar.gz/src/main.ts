console.error(
  JSON.stringify({
    error: { code: 'NOT_IMPLEMENTED', message: 'Implement the store' },
  }),
);
process.exit(70);
