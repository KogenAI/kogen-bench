# Atomic reference store

Build offline with `make build`; run `./bin/app COMMAND --root DIR FLAGS`.
`make check` runs the stack checks; `make test` runs public tests.
The supplied CLI skeleton returns NOT_IMPLEMENTED, exit 70.
See the task statement for the full contract.
