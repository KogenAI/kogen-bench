package main

import (
	"encoding/base64"
	"path/filepath"
	"testing"
)

func TestPlaceholder(t *testing.T) {
	if 2+2 != 4 {
		t.Fatal("arithmetic")
	}
}
func TestAbsolutePath(t *testing.T) {
	if !filepath.IsAbs("/usr/bin") {
		t.Fatal("absolute path")
	}
}
func TestBase64Padding(t *testing.T) {
	if base64.StdEncoding.EncodeToString([]byte{0, 255}) != "AP8=" {
		t.Fatal("base64")
	}
}
