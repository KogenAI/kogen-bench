module bounded

go 1.27.1
