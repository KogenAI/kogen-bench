export function identity(): string {
  return 'config-migrator';
}
