import { expect, test } from 'bun:test';
import { identity } from '../src/core';

test('identity', () => {
  expect(identity()).toEqual('config-migrator');
});
test('nonempty', () => {
  expect(identity().length > 0).toEqual(true);
});
