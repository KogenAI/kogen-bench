package main

import (
	"crypto/sha256"
	"encoding/json"
	"testing"
)

func TestJSON(t *testing.T) {
	if !json.Valid([]byte(`{"ok":true}`)) {
		t.Fatal("json")
	}
}
func TestHash(t *testing.T) {
	if len(sha256.Sum256(nil)) != 32 {
		t.Fatal("hash")
	}
}
