fn identity() -> &'static str {
    "config-migrator"
}
fn main() {
    let _ = identity();
    eprintln!("{{\"error\":{{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"not implemented\"}}}}");
    std::process::exit(70);
}
#[cfg(test)]
mod tests {
    #[test]
    fn name() {
        assert_eq!(super::identity(), "config-migrator");
    }
    #[test]
    fn name_is_nonempty() {
        assert!(!super::identity().is_empty());
    }
}
