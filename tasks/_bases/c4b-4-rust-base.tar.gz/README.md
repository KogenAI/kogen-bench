# Configuration migrator starter

Build offline with `make build`, then run `./bin/app` as described in the task. `make test` runs public unit tests; `make check` runs all stack checks. The executable is a placeholder returning NOT_IMPLEMENTED (70). Keep the implementation in process in this stack.
