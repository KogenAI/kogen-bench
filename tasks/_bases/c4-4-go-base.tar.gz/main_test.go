package main

import (
	"encoding/json"
	"sort"
	"testing"
)

func TestJSON(t *testing.T) {
	var v map[string]any
	if err := json.Unmarshal([]byte(`{"revision":1}`), &v); err != nil {
		t.Fatal(err)
	}
	if v["revision"] != float64(1) {
		t.Fatal(v)
	}
}

func TestSort(t *testing.T) {
	names := []string{"z", "A", "a"}
	sort.Strings(names)
	if names[0] != "A" {
		t.Fatal(names)
	}
}
