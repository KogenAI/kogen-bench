package main

import (
	"errors"
	"syscall"
)

// lockExclusive locks an already-open stable .lock; close the file to release.
func lockExclusive(fd int) error {
	for {
		err := syscall.Flock(fd, syscall.LOCK_EX)
		if !errors.Is(err, syscall.EINTR) {
			return err
		}
	}
}
