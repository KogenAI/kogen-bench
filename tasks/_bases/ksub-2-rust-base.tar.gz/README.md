# Rust approval desk

Build the executable with `make build`. Every command currently reports
`NOT_IMPLEMENTED`. `make check` runs formatting, Clippy and unit tests; `make
test` runs the unit tests.
