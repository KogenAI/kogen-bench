pub fn execute() -> Result<(), &'static str> {
    Err("subcommands are not implemented")
}

#[cfg(test)]
mod tests {
    #[test]
    fn skeleton_reports_not_implemented() {
        assert_eq!(super::execute(), Err("subcommands are not implemented"));
    }

    #[test]
    fn error_code_is_stable() {
        assert!(include_str!("main.rs").contains("NOT_IMPLEMENTED"));
    }
}
