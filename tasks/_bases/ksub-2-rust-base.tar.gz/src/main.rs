use std::io::{self, Write};

fn main() {
    let body = b"{\"error\":{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"subcommands are not implemented\"}}\n";
    let _ = io::stderr().write_all(body);
    std::process::exit(70);
}
