#[allow(dead_code)]
mod digest;
fn main() {
    eprintln!(
        "{{\"error\":{{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"Implement the watcher\"}}}}"
    );
    std::process::exit(70);
}

#[cfg(test)]
mod tests {
    #[test]
    fn json_available() {
        assert_eq!(serde_json::json!({"ok": true})["ok"], true);
    }
}
