package main

import "testing"

func TestSkeleton(t *testing.T) {
	if 2+2 != 4 {
		t.Fatal("arithmetic")
	}
}
