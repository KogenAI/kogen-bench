package main

import (
	"fmt"
	"os"
)

func main() {
	fmt.Fprintln(os.Stderr, `{"error":{"code":"NOT_IMPLEMENTED","message":"Implement the store"}}`)
	os.Exit(70)
}
