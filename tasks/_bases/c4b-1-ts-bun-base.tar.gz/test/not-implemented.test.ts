import { describe, expect, test } from 'bun:test';
import { notImplemented } from '../src/not-implemented.ts';

describe('notImplemented', () => {
  test('returns the documented error code', () => {
    expect(notImplemented().error.code).toBe('NOT_IMPLEMENTED');
  });

  test('includes a readable message', () => {
    expect(notImplemented().error.message.length).toBeGreaterThan(0);
  });
});
