# Resumable build queue base

This repository is the TypeScript/Bun starter for the resumable build queue.
The command entry point compiles to `./bin/app` and currently reports that the
requested command is not implemented.

Run `make setup` to copy the pinned offline TypeScript and Biome packages from
the Bun toolchain. Then run `make build`, `make check`, and `make test`.

The compiled program accepts the task's command line and emits the required
`NOT_IMPLEMENTED` error with exit status 70 until the queue is implemented.
