import { notImplemented } from './not-implemented.ts';

process.stderr.write(`${JSON.stringify(notImplemented())}\n`);
process.exit(70);
