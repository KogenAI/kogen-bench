export interface NotImplementedError {
  error: {
    code: 'NOT_IMPLEMENTED';
    message: string;
  };
}

export function notImplemented(): NotImplementedError {
  return {
    error: {
      code: 'NOT_IMPLEMENTED',
      message: 'This command is not implemented yet.',
    },
  };
}
