# Segmented store (TypeScript/Bun)

Build offline with `make build`; run `./bin/app COMMAND --root DIR [FLAGS]`. `make test` runs public unit tests; `make check` runs tsc --noEmit (strict), biome check ., bun test. The initial CLI reports NOT_IMPLEMENTED (exit 70). Implement SPEC in this stack, entirely in process.

The lock helper opens a stable file and uses native Linux flock, retries EINTR and releases on close/process exit. Mode 1 is shared, 2 exclusive; use `.lock` and `.compact.lock` as specified. Record, replay and compaction modules are yours to implement.
