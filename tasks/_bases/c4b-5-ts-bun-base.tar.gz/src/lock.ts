import { dlopen, FFIType, read } from 'bun:ffi';
import { closeSync, openSync } from 'node:fs';

const native = dlopen('libc.so.6', {
  flock: { args: [FFIType.i32, FFIType.i32], returns: FFIType.i32 },
  __errno_location: { args: [], returns: FFIType.ptr },
}).symbols;
export function lock(path: string, mode: number): number {
  const fd = openSync(path, 'a+');
  while (native.flock(fd, mode) !== 0) {
    if (read.i32(native.__errno_location()) !== 4) {
      closeSync(fd);
      throw new Error('flock failed');
    }
  }
  return fd;
}
export function unlock(fd: number): void {
  native.flock(fd, 8);
  closeSync(fd);
}
