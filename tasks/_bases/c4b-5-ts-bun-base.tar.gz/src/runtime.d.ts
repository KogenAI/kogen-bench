declare const Bun: {
  stdin: { arrayBuffer(): Promise<ArrayBuffer> };
  file(path: string): { arrayBuffer(): Promise<ArrayBuffer> };
  stdout: unknown;
  stderr: unknown;
  write(target: unknown, text: string): Promise<number>;
};
declare const process: { argv: string[]; exit(code: number): never };
declare module 'bun:test' {
  export function test(name: string, fn: () => void): void;
  export function expect(value: unknown): { toEqual(expected: unknown): void };
}
declare module 'node:fs' {
  export function openSync(path: string, flags: string, mode?: number): number;
  export function closeSync(fd: number): void;
  export function fsyncSync(fd: number): void;
  export function ftruncateSync(fd: number, length: number): void;
  export function writeSync(fd: number, data: Uint8Array): number;
  export function readFileSync(path: string): Uint8Array;
  export function writeFileSync(path: string, data: string | Uint8Array): void;
  export function existsSync(path: string): boolean;
  export function mkdirSync(
    path: string,
    options: { recursive: boolean },
  ): void;
  export function renameSync(oldPath: string, newPath: string): void;
  export function unlinkSync(path: string): void;
}
declare module 'bun:ffi' {
  export const FFIType: { i32: string; ptr: string };
  export function dlopen(
    path: string,
    symbols: Record<string, { args: string[]; returns: string }>,
  ): { symbols: Record<string, (...args: number[]) => number> };
  export const read: { i32(ptr: number): number };
}
