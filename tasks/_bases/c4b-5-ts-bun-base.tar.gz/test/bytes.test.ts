import { expect, test } from 'bun:test';

test('empty bytes', () =>
  expect(new TextEncoder().encode('').length).toEqual(0));
test('ASCII bytes', () => expect(new TextEncoder().encode('A')[0]).toEqual(65));
