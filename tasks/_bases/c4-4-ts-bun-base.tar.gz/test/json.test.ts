import { expect, test } from 'bun:test';

test('JSON preserves revision', () => {
  expect(JSON.parse('{"revision":1}')).toEqual({ revision: 1 });
});

test('ASCII ordering', () => {
  expect(['z', 'A', 'a'].sort()).toEqual(['A', 'a', 'z']);
});
