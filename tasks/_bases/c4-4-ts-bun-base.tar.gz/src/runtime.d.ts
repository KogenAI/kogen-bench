declare const process: {
  argv: string[];
  exit(code: number): never;
  pid: number;
};
declare module 'bun:test' {
  export function test(name: string, fn: () => void): void;
  export function expect(value: unknown): { toEqual(expected: unknown): void };
}
declare module 'bun:ffi' {
  export const read: { i32(pointer: number): number };
  export function dlopen(
    path: string,
    symbols: Record<string, { args: string[]; returns: string }>,
  ): { symbols: Record<string, (...args: number[]) => number> };
}
