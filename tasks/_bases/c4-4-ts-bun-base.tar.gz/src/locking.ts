import { dlopen } from 'bun:ffi';

// Linux libc ABI. Close the stable .lock descriptor to release this lock.
const libc = dlopen('libc.so.6', {
  flock: { args: ['i32', 'i32'], returns: 'i32' },
  __errno_location: { args: [], returns: 'ptr' },
});

import { read } from 'bun:ffi';
export function lockExclusive(fd: number): void {
  while (libc.symbols.flock(fd, 2) !== 0) {
    if (read.i32(libc.symbols.__errno_location()) !== 4)
      throw new Error('flock failed');
  }
}
