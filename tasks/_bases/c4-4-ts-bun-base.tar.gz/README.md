# Change workflow (TypeScript/Bun)

Run `make build`, then `./bin/app COMMAND --state DIR FLAGS`.
Run `make check` for all required stack checks, or `make test` for unit tests.
The starter deliberately returns NOT_IMPLEMENTED (exit 70) for every command.
Dependencies use the installed offline toolchain; no downloads are needed.

Linux locking support is supplied: import `lockExclusive` from `./locking`; call it with the open `.lock` descriptor. It uses the standard `bun:ffi` API and Linux libc, with EINTR retry. Hold that file open through the protected operation and close it to release the lock.
