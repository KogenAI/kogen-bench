fn main() {
    eprintln!("{{\"error\":{{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"not implemented\"}}}}");
    std::process::exit(70);
}
#[cfg(test)]
mod tests {
    #[test]
    fn absolute_path() {
        assert!(std::path::Path::new("/usr/bin").is_absolute());
    }
    #[test]
    fn marker_is_ascii() {
        assert!("[truncated]".is_ascii());
    }
    #[test]
    fn placeholder() {
        assert_eq!(2 + 2, 4);
    }
}
