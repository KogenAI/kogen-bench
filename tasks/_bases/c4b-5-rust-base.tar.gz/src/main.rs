mod lock;
fn main() {
    eprintln!("{{\"error\":{{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"Implement the store\"}}}}");
    std::process::exit(70);
}
