use std::fs::{File, OpenOptions};
use std::io;
use std::os::fd::AsRawFd;
use std::path::Path;
unsafe extern "C" {
    fn flock(fd: i32, op: i32) -> i32;
}
#[allow(dead_code)]
pub struct Lock(File);
#[allow(dead_code)]
impl Lock {
    pub fn acquire(path: &Path, mode: i32) -> io::Result<Self> {
        let f = OpenOptions::new()
            .create(true)
            .truncate(false)
            .read(true)
            .write(true)
            .open(path)?;
        loop {
            if unsafe { flock(f.as_raw_fd(), mode) } == 0 {
                return Ok(Self(f));
            }
            let e = io::Error::last_os_error();
            if e.kind() != io::ErrorKind::Interrupted {
                return Err(e);
            }
        }
    }
}
impl Drop for Lock {
    fn drop(&mut self) {
        unsafe {
            flock(self.0.as_raw_fd(), 8);
        }
    }
}
#[cfg(test)]
mod tests {
    #[test]
    fn native_modes() {
        assert_eq!(1 | 2, 3);
    }
    #[test]
    fn pointer_width() {
        assert!(std::mem::size_of::<usize>() >= 4);
    }
}
