package main

import "testing"

func TestModes(t *testing.T) {
	if 1|2 != 3 {
		t.Fatal("modes")
	}
}
func TestEmptyBytes(t *testing.T) {
	if len([]byte("")) != 0 {
		t.Fatal("bytes")
	}
}
