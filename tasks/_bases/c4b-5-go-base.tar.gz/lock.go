package main

import (
	"os"
	"syscall"
)

func lock(path string, mode int) (*os.File, error) {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0600)
	if e != nil {
		return nil, e
	}
	for {
		e = syscall.Flock(int(f.Fd()), mode)
		if e != syscall.EINTR {
			break
		}
	}
	if e != nil {
		_ = f.Close()
		return nil, e
	}
	return f, nil
}
func unlock(f *os.File) { _ = syscall.Flock(int(f.Fd()), syscall.LOCK_UN); _ = f.Close() }
