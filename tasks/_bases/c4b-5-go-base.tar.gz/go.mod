module segstore

go 1.27.1
