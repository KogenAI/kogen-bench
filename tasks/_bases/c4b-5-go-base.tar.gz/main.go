package main

import (
	"fmt"
	"os"
)

func main() {
	_ = lock
	_ = unlock
	fmt.Fprintln(os.Stderr, `{"error":{"code":"NOT_IMPLEMENTED","message":"Implement the store"}}`)
	os.Exit(70)
}
