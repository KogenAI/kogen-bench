use std::io::{self, Write};

fn main() {
    let _args: Vec<String> = std::env::args().skip(1).collect();
    let error = serde_json::json!({
        "error": {
            "code": "NOT_IMPLEMENTED",
            "message": "the resumable build queue is not implemented"
        }
    });
    let _ = writeln!(io::stderr(), "{error}");
    std::process::exit(70);
}

#[cfg(test)]
mod tests {
    #[test]
    fn manifest_step_count_is_bounded() {
        assert!((1..=32).contains(&1));
        assert!((1..=32).contains(&32));
        assert!(!(1..=32).contains(&0));
    }
}
