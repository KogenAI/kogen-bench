# Resumable build queue (Rust)

Build the command with `make build`, then run it as `./bin/app`. The base
contains the command interface and build checks; implementation commands return
`NOT_IMPLEMENTED` until the queue is added.

Run `make check` to verify formatting, Clippy warnings, and unit tests. Cargo is
configured to use the host's preinstalled vendor directory and to stay offline.
