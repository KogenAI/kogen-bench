# Approval desk (TypeScript/Bun)

Build the command with `make build`. The resulting `./bin/app` accepts the
subcommands and flags described in the task specification. Run the repository
checks with `make check` or just the public tests with `make test`.

The setup step copies the pinned TypeScript and Biome tools from the offline
Bun toolchain template; it does not access the network.
