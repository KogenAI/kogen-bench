import { notImplemented } from './shared.ts';

async function main(): Promise<void> {
  await Bun.write(Bun.stderr, `${JSON.stringify(notImplemented())}\n`);
  process.exit(70);
}

await main();
