declare const Bun: {
  stdin: { arrayBuffer(): Promise<ArrayBuffer> };
  stdout: unknown;
  stderr: unknown;
  write(target: unknown, text: string): Promise<number>;
};

declare const process: {
  argv: string[];
  env: Record<string, string | undefined>;
  exitCode: number | undefined;
  pid: number;
  kill(pid: number, signal: 'SIGKILL'): void;
  exit(code: number): never;
};

declare const Buffer: {
  from(text: string, encoding: 'utf8'): Uint8Array;
};

declare module 'bun:test' {
  export function test(name: string, fn: () => void): void;
  export function expect(value: unknown): { toEqual(expected: unknown): void };
}

declare module 'bun:ffi' {
  export const FFIType: { readonly i32: number };
  export function dlopen(
    path: string,
    declarations: Record<string, { args: unknown[]; returns: unknown }>,
  ): { symbols: Record<string, (...args: number[]) => number> };
}

declare module 'node:crypto' {
  interface Hash {
    update(text: string, encoding: 'utf8'): Hash;
    digest(encoding: 'hex'): string;
  }
  export function createHash(algorithm: 'sha256'): Hash;
}

declare module 'node:fs' {
  export const constants: {
    O_RDONLY: number;
    O_RDWR: number;
    O_CREAT: number;
    O_WRONLY: number;
    O_APPEND: number;
  };
  export function closeSync(fd: number): void;
  export function existsSync(path: string): boolean;
  export function ftruncateSync(fd: number, length: number): void;
  export function fsyncSync(fd: number): void;
  export function mkdirSync(
    path: string,
    options: { recursive: boolean },
  ): void;
  export function openSync(path: string, flags: number, mode?: number): number;
  export function readFileSync(path: string): Uint8Array;
  export function writeFileSync(path: string, data: string): void;
  export function writeSync(
    fd: number,
    data: Uint8Array,
    offset: number,
    length: number,
  ): number;
}

declare module 'node:path' {
  export function join(...paths: string[]): string;
}
