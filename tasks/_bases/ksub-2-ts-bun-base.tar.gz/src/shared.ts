export function notImplemented(): { error: { code: string; message: string } } {
  return {
    error: {
      code: 'NOT_IMPLEMENTED',
      message: 'This command is not implemented',
    },
  };
}
