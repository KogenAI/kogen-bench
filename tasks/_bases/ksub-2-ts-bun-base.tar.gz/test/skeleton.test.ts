import { expect, test } from 'bun:test';
import { notImplemented } from '../src/shared.ts';

test('exposes the documented placeholder error', () => {
  expect(notImplemented()).toEqual({
    error: {
      code: 'NOT_IMPLEMENTED',
      message: 'This command is not implemented',
    },
  });
});
