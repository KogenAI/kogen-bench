pub fn valid_name(s: &str) -> bool {
    let b = s.as_bytes();
    !b.is_empty()
        && b.len() <= 40
        && b[0].is_ascii_lowercase()
        && b.iter()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || *c == b'_' || *c == b'-')
}

#[cfg(test)]
mod tests {
    use super::valid_name;
    #[test]
    fn ordinary_name() {
        assert!(valid_name("fix-2_a"));
    }
    #[test]
    fn empty_name() {
        assert!(!valid_name(""));
    }
    #[test]
    fn traversal_name() {
        assert!(!valid_name("../bad"));
    }
}
