fn main() {
    eprintln!(
        "{}",
        serde_json::json!({"error":{"code":"NOT_IMPLEMENTED","message":"Implement the CLI"}})
    );
    std::process::exit(70);
}
