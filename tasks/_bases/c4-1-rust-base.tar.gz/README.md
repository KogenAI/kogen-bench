# Worktree landing queue (rust)

Implement the contract in the supplied prompt. The starter reports
`NOT_IMPLEMENTED` (exit 70) for every invocation.

Run `make build` to produce `bin/app`, `make test` for public unit tests,
and `make check` for all formatting, static analysis, and unit checks.
Dependencies and toolchains are supplied by the offline Linux environment.
Invoke `./bin/app list --root /tmp/queue` after implementing initialization.
