package main

import (
	"fmt"
	"os"
)

func identity() string { return "config-migrator" }
func main() {
	_ = identity()
	fmt.Fprintln(os.Stderr, `{"error":{"code":"NOT_IMPLEMENTED","message":"not implemented"}}`)
	os.Exit(70)
}
