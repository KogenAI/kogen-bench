module config-migrator

go 1.27.1
