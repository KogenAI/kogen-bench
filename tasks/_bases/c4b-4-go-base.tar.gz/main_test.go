package main

import "testing"

func TestIdentity(t *testing.T) {
	if identity() != "config-migrator" {
		t.Fatal("identity")
	}
}
func TestNonempty(t *testing.T) {
	if identity() == "" {
		t.Fatal("empty")
	}
}
