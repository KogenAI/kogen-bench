# Approval desk (Go)

Build the command with `make build`. The executable is `./bin/app`.

Run `make check` to format-check, vet, lint, and test the Go sources. The
project uses only the Go standard library and does not download dependencies.

The base is a fixed placeholder: every invocation ignores its arguments and
input, writes one `NOT_IMPLEMENTED` JSON error to standard error, and exits 70.
The implementation belongs in the task solution.
