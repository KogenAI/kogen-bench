package main

import "testing"

func TestPlaceholderErrorLine(t *testing.T) {
	want := "{\"error\":{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"subcommands are not implemented\"}}\n"
	if got := string(placeholderErrorLine()); got != want {
		t.Fatalf("placeholderErrorLine() = %q, want %q", got, want)
	}
}
