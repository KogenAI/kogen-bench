module approvaldesk

go 1.27.1
