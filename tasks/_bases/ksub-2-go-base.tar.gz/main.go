package main

import "os"

const notImplementedLine = "{\"error\":{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"subcommands are not implemented\"}}\n"

func placeholderErrorLine() []byte {
	return []byte(notImplementedLine)
}

func main() {
	_, _ = os.Stderr.Write(placeholderErrorLine())
	os.Exit(70)
}
