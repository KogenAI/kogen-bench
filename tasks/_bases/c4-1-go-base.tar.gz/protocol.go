package main

func validName(s string) bool {
	if len(s) == 0 || len(s) > 40 || s[0] < 'a' || s[0] > 'z' {
		return false
	}
	for _, c := range s {
		if (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-' {
			continue
		}
		return false
	}
	return true
}
