package main

import "testing"

func TestName(t *testing.T) {
	if !validName("fix-2_a") {
		t.Fatal("valid name rejected")
	}
}
func TestEmpty(t *testing.T) {
	if validName("") {
		t.Fatal("empty accepted")
	}
}
func TestTraversal(t *testing.T) {
	if validName("../bad") {
		t.Fatal("traversal accepted")
	}
}
