mod locking;
pub use locking::lock_exclusive;
fn main() {
    eprintln!("{{\"error\":{{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"not implemented\"}}}}");
    std::process::exit(70);
}

#[cfg(test)]
mod tests {
    #[test]
    fn json_round_trip() {
        let value = serde_json::json!({"revision": 1, "approvers": []});
        assert_eq!(
            serde_json::from_str::<serde_json::Value>(&value.to_string()).unwrap(),
            value
        );
    }
    #[test]
    fn sorted_names() {
        let mut names = ["z", "A", "a"];
        names.sort();
        assert_eq!(names, ["A", "a", "z"]);
    }
}
