use std::os::fd::AsRawFd;

// Lock an already-open stable .lock; dropping the file releases the lock.
pub fn lock_exclusive(file: &std::fs::File) -> std::io::Result<()> {
    loop {
        if unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_EX) } == 0 {
            return Ok(());
        }
        let err = std::io::Error::last_os_error();
        if err.kind() != std::io::ErrorKind::Interrupted {
            return Err(err);
        }
    }
}
