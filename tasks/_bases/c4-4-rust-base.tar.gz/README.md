# Change workflow (Rust)

Run `make build`, then `./bin/app COMMAND --state DIR FLAGS`.
Run `make check` for all required stack checks, or `make test` for unit tests.
The starter deliberately returns NOT_IMPLEMENTED (exit 70) for every command.
Dependencies use the installed offline toolchain; no downloads are needed.

Linux locking support is supplied: declare `mod locking;` and call `locking::lock_exclusive(&file)` on an open `.lock` file. Hold that file open through the protected operation and close it to release the lock.
