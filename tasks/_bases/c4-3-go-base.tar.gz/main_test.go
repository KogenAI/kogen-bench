package main

import (
	"encoding/json"
	"testing"
)

func TestEmptySpec(t *testing.T) {
	var v map[string]any
	if err := json.Unmarshal([]byte(`{"children":[]}`), &v); err != nil {
		t.Fatal(err)
	}
	if len(v) != 1 {
		t.Fatal("bad shape")
	}
}
func TestStatus(t *testing.T) {
	if 143 != 128+15 {
		t.Fatal("bad signal status")
	}
}
