fn main() {
    eprintln!("{{\"error\":{{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"implement run\"}}}}");
    std::process::exit(70);
}

#[cfg(test)]
mod tests {
    #[test]
    fn parses_json() {
        let value: serde_json::Value = serde_json::from_str("{\"children\":[]}").unwrap();
        assert!(value["children"].as_array().unwrap().is_empty());
    }
    #[test]
    fn pid_type() {
        assert_eq!(std::mem::size_of::<libc::pid_t>(), 4);
    }
}
