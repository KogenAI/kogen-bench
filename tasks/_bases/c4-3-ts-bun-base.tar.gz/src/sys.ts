import { dlopen } from 'bun:ffi';

// Raw Linux/glibc declarations; callers allocate ABI buffers and choose policy.
export const PR_SET_CHILD_SUBREAPER = 36;
export const WNOHANG = 1;

export const libc = dlopen('libc.so.6', {
  prctl: { args: ['i32', 'u64', 'u64', 'u64', 'u64'], returns: 'i32' },
  waitpid: { args: ['i32', 'ptr', 'i32'], returns: 'i32' },
  setpgid: { args: ['i32', 'i32'], returns: 'i32' },
  getpgid: { args: ['i32'], returns: 'i32' },
  __errno_location: { args: [], returns: 'ptr' },
  kill: { args: ['i32', 'i32'], returns: 'i32' },
  posix_spawn: {
    args: ['ptr', 'ptr', 'ptr', 'ptr', 'ptr', 'ptr'],
    returns: 'i32',
  },
  posix_spawnattr_init: { args: ['ptr'], returns: 'i32' },
  posix_spawnattr_destroy: { args: ['ptr'], returns: 'i32' },
  posix_spawnattr_setpgroup: { args: ['ptr', 'i32'], returns: 'i32' },
  posix_spawnattr_setflags: { args: ['ptr', 'i16'], returns: 'i32' },
  posix_spawnattr_setsigmask: { args: ['ptr', 'ptr'], returns: 'i32' },
  posix_spawnattr_setsigdefault: { args: ['ptr', 'ptr'], returns: 'i32' },
  sigemptyset: { args: ['ptr'], returns: 'i32' },
  sigfillset: { args: ['ptr'], returns: 'i32' },
  posix_spawn_file_actions_init: { args: ['ptr'], returns: 'i32' },
  posix_spawn_file_actions_destroy: { args: ['ptr'], returns: 'i32' },
  posix_spawn_file_actions_addopen: {
    args: ['ptr', 'i32', 'ptr', 'i32', 'u32'],
    returns: 'i32',
  },
  posix_spawn_file_actions_addchdir_np: {
    args: ['ptr', 'ptr'],
    returns: 'i32',
  },
});
