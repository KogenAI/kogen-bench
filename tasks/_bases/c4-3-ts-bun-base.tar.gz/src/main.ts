console.error(
  JSON.stringify({
    error: { code: 'NOT_IMPLEMENTED', message: 'implement run' },
  }),
);
process.exit(70);
