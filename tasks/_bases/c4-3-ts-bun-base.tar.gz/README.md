# Process supervisor starter

Run `make build`, then `./bin/app run --root DIR --spec spec.json`.
Run `make check` for all stack checks, or `make test` for public tests.
Builds use the installed offline toolchains. The starter returns NOT_IMPLEMENTED (70).
`src/sys.ts` provides raw offline Linux libc syscall/spawn bindings; it contains no supervisor logic.
