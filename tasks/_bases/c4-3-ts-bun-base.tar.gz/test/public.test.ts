import { expect, test } from 'bun:test';

test('empty spec shape', () => {
  expect(JSON.parse('{"children":[]}')).toEqual({ children: [] });
});
test('termination status', () => {
  expect(128 + 15).toBe(143);
});
