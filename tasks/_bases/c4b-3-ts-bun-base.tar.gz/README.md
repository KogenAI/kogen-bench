# Tree watcher

Build offline with `make build`, run `./bin/app`, validate with `make check`,
and run public unit tests with `make test`. See the task statement for the CLI.
