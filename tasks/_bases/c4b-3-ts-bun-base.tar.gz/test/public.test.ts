import { expect, test } from 'bun:test';

test('JSON round trip', () => {
  expect(JSON.parse(JSON.stringify({ ok: true }))).toEqual({ ok: true });
});
test('bytes', () => {
  expect(Buffer.from('é').length).toBe(2);
});
