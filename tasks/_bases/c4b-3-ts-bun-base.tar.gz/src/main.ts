console.error(
  JSON.stringify({
    error: { code: 'NOT_IMPLEMENTED', message: 'Implement the watcher' },
  }),
);
process.exit(70);
