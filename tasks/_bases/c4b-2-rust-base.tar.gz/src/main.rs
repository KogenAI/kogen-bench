fn main() {
    eprintln!("{{\"error\":{{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"Implement the store\"}}}}");
    std::process::exit(70);
}

#[test]
fn skeleton_contract() {
    assert_eq!(2 + 2, 4);
}
