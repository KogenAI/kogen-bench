declare const Bun: {
  stderr: unknown;
  write(target: unknown, text: string): Promise<number>;
};

declare const process: {
  argv: string[];
  exit(code: number): never;
};

declare module 'bun:test' {
  export function test(name: string, fn: () => void | Promise<void>): void;
  export function expect(value: unknown): {
    toEqual(expected: unknown): void;
    toBe(expected: unknown): void;
  };
}
