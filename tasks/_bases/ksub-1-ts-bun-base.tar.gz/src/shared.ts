export class Failure extends Error {
  constructor(
    public code: number,
    message: string,
  ) {
    super(message);
  }
}

export function notImplemented(command: string): Failure {
  return new Failure(70, `${command} is not implemented`);
}

export function compactError(code: string, message: string): string {
  return JSON.stringify({ error: { code, message } });
}
