import { Failure, notImplemented } from './shared.ts';

const command = process.argv[2] ?? '';
await writeError(notImplemented(command));

async function writeError(error: Failure): Promise<never> {
  await Bun.write(
    Bun.stderr,
    `${JSON.stringify({
      error: {
        code: error.code === 70 ? 'NOT_IMPLEMENTED' : 'USAGE',
        message: error.message,
      },
    })}\n`,
  );
  process.exit(error.code);
}
