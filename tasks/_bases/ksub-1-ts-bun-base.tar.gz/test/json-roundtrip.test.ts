import { expect, test } from 'bun:test';

test('a JSON document survives a native round trip', () => {
  const source = '{"queue":[{"id":"item-1","turns":2},null],"ready":true}';
  expect(JSON.stringify(JSON.parse(source))).toBe(source);
});
