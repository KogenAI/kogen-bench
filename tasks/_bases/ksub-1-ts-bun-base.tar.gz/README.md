# Durable change queue (TS/Bun base)

Build the command with `make build`, then run `./bin/app` with the arguments
described in the task specification. `make check` runs the strict TypeScript,
Biome, and Bun test checks offline. Run `./setup.sh` once when preparing the
provided Bun toolchain outside the grade sandbox.

This is the no-solution starting point. Commands report `NOT_IMPLEMENTED` until
the queue logic is implemented.
