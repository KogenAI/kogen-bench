package main

import "testing"

func TestSkeletonReturnsNotImplemented(t *testing.T) {
	output, code := execute([]string{"status", "--root", "unused"})
	if code != 70 {
		t.Fatalf("exit code = %d, want 70", code)
	}
	if output != "{\"error\":{\"code\":\"NOT_IMPLEMENTED\",\"message\":\"command is not implemented\"}}\n" {
		t.Fatalf("unexpected output: %q", output)
	}
}
