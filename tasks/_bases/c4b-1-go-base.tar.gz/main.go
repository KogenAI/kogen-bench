package main

import (
	"fmt"
	"os"
)

func execute(_ []string) (string, int) {
	return `{"error":{"code":"NOT_IMPLEMENTED","message":"command is not implemented"}}` + "\n", 70
}

func main() {
	output, code := execute(os.Args[1:])
	_, _ = fmt.Fprint(os.Stderr, output)
	os.Exit(code)
}
