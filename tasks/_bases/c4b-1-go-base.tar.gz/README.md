# Resumable build queue

Build the command with `make build`; it produces `./bin/app`. The command
accepts `init`, `enqueue`, `run`, `status`, and `events`, each with
`--root DIR`; `enqueue` also takes `--manifest REL`, and `run` optionally takes
`--grace-ms N`.

Run `make check` for formatting, static analysis, lint, and tests. The base is
a compiling skeleton: every invocation returns `NOT_IMPLEMENTED` with exit
code 70.
