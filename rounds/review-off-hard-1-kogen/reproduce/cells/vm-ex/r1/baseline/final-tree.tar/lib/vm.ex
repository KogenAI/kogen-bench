defmodule Kogen.VM do
  @moduledoc "Parse and execute a bounded integer stack program using exact integers."
  import Kogen.Input, only: [fail: 1]
  @bound 999_999_999
  @arity %{
    "PUSH" => 1,
    "DUP" => 0,
    "DROP" => 0,
    "SWAP" => 0,
    "ADD" => 0,
    "SUB" => 0,
    "MUL" => 0,
    "DIV" => 0,
    "MOD" => 0,
    "OUT" => 0,
    "JMP" => 1,
    "JZ" => 1,
    "HALT" => 0
  }

  @doc "Return all output on success; raise Kogen.Error without output on failure."
  def run(bytes, steps \\ 10000, stack_limit \\ 256) do
    if byte_size(bytes) > 1_048_576, do: fail("vm: input too large")
    lines = Kogen.Input.physical_lines(bytes)

    for {line, number} <- Enum.with_index(lines, 1) do
      case Enum.find_index(:binary.bin_to_list(line), &(&1 > 127)) do
        nil -> :ok
        column -> error(number, column + 1, "expected ASCII")
      end
    end

    {instructions, labels, _} =
      lines
      |> Enum.with_index(1)
      |> Enum.reduce({[], [], 0}, fn {line, number}, {instructions, labels, count} ->
        if Regex.match?(~r/\A[ \t]*(?:#.*)?\z/, line) do
          {instructions, labels, count}
        else
          if count == 10000, do: error(number, 1, "too many records")

          case :binary.match(line, "\t") do
            :nomatch -> :ok
            {column, _} -> error(number, column + 1, "tab is not allowed")
          end

          code =
            case :binary.match(line, " #") do
              :nomatch -> line
              {offset, _} -> binary_part(line, 0, offset)
            end

          tokens =
            code
            |> then(&Regex.scan(~r/[^ ]+/, &1, return: :index))
            |> Enum.map(fn [{offset, size}] -> {binary_part(line, offset, size), offset + 1} end)

          [{name, column} | operands] = tokens

          if String.ends_with?(name, ":") do
            if operands != [], do: error(number, column, "wrong operand count")

            unless Regex.match?(~r/\A[a-z][a-z0-9_]{0,15}:\z/, name),
              do: error(number, column, "invalid label")

            label = String.trim_trailing(name, ":")
            {instructions, [{label, length(instructions), number, column} | labels], count + 1}
          else
            arity = Map.get(@arity, name)
            if arity == nil, do: error(number, column, "unknown instruction")
            if length(operands) != arity, do: error(number, column, "wrong operand count")
            operand = parse_operand(name, operands, number)
            {[{name, operand, number, column} | instructions], labels, count + 1}
          end
        end
      end)

    targets =
      labels
      |> Enum.reverse()
      |> Enum.reduce(%{}, fn {name, position, line, column}, targets ->
        if Map.has_key?(targets, name), do: error(line, column, "duplicate label")
        Map.put(targets, name, position)
      end)

    program =
      instructions
      |> Enum.reverse()
      |> Enum.map(fn
        {op, {target, col}, line, column} when op in ["JMP", "JZ"] ->
          unless Map.has_key?(targets, target), do: error(line, col, "unknown label")
          {op, Map.fetch!(targets, target), line, column}

        instruction ->
          instruction
      end)
      |> List.to_tuple()

    execute(program, 0, [], 0, [], 0, steps, stack_limit)
  end

  defp parse_operand("PUSH", [{token, column}], line) do
    unless Regex.match?(~r/\A[+-]?[0-9]+\z/, token), do: error(line, column, "invalid integer")
    value = String.to_integer(token)
    if abs(value) > @bound, do: error(line, column, "integer out of range")
    value
  end

  defp parse_operand(op, [{token, column}], line) when op in ["JMP", "JZ"] do
    unless Regex.match?(~r/\A[a-z][a-z0-9_]{0,15}\z/, token),
      do: error(line, column, "invalid label")

    {token, column}
  end

  defp parse_operand(_, [], _), do: nil

  defp execute(program, pc, stack, depth, output, used, steps, limit) do
    if pc == tuple_size(program) do
      output |> Enum.reverse() |> IO.iodata_to_binary()
    else
      {op, operand, line, column} = elem(program, pc)
      if used == steps, do: error(line, column, "step limit exceeded")

      required =
        cond do
          op in ["SWAP", "ADD", "SUB", "MUL", "DIV", "MOD"] -> 2
          op in ["DUP", "DROP", "OUT", "JZ"] -> 1
          true -> 0
        end

      if depth < required, do: error(line, column, "stack underflow")
      if op in ["PUSH", "DUP"] and depth == limit, do: error(line, column, "stack overflow")

      case {op, stack} do
        {"HALT", _} ->
          output |> Enum.reverse() |> IO.iodata_to_binary()

        {"PUSH", _} ->
          execute(program, pc + 1, [operand | stack], depth + 1, output, used + 1, steps, limit)

        {"DUP", [top | _]} ->
          execute(program, pc + 1, [top | stack], depth + 1, output, used + 1, steps, limit)

        {"DROP", [_ | tail]} ->
          execute(program, pc + 1, tail, depth - 1, output, used + 1, steps, limit)

        {"SWAP", [right, left | tail]} ->
          execute(program, pc + 1, [left, right | tail], depth, output, used + 1, steps, limit)

        {"OUT", [top | tail]} ->
          execute(
            program,
            pc + 1,
            tail,
            depth - 1,
            [Integer.to_string(top) <> "\n" | output],
            used + 1,
            steps,
            limit
          )

        {"JMP", _} ->
          execute(program, operand, stack, depth, output, used + 1, steps, limit)

        {"JZ", [top | tail]} ->
          execute(
            program,
            if(top == 0, do: operand, else: pc + 1),
            tail,
            depth - 1,
            output,
            used + 1,
            steps,
            limit
          )

        {arithmetic, [right, left | tail]} ->
          if arithmetic in ["DIV", "MOD"] and right == 0,
            do: error(line, column, "division by zero")

          value =
            case arithmetic do
              "ADD" -> left + right
              "SUB" -> left - right
              "MUL" -> left * right
              "DIV" -> div(left, right)
              "MOD" -> rem(left, right)
            end

          if abs(value) > @bound, do: error(line, column, "integer overflow")
          execute(program, pc + 1, [value | tail], depth - 1, output, used + 1, steps, limit)
      end
    end
  end

  defp error(line, column, message), do: fail("vm:#{line}:#{column}: #{message}")
end
