defmodule Kogen.Core do
  @moduledoc "Argument handling for the bounded stack machine."
  import Kogen.Input, only: [fail: 2]

  @help "Usage: kogen-vm [--steps N] [--stack N] [FILE|-]\nRun a bounded integer stack program.\nOptions:\n  --steps N    Maximum instructions executed (default 10000).\n  --stack N    Maximum stack depth (default 256).\n  --help       Show this help.\n"

  def execute(["--help"]), do: @help

  def execute(args) do
    options = options(args)
    options.path |> Kogen.Input.read("vm") |> Kogen.VM.run(options.steps, options.stack)
  end

  @doc "Validate command-line arguments before any input is read."
  def options(args), do: scan(args, %{steps: 10000, stack: 256, path: nil}, [])

  defp scan([], options, _seen), do: options

  defp scan([option | rest], options, seen) when option in ["--steps", "--stack"] do
    if option in seen, do: fail("vm: duplicate option '#{option}'", 2)

    case rest do
      [] ->
        fail("vm: option '#{option}' requires a value", 2)

      [value | tail] ->
        unless Regex.match?(~r/\A[0-9]+\z/, value),
          do: fail("vm: invalid value for '#{option}': '#{value}'", 2)

        number = String.to_integer(value)
        {key, maximum} = if option == "--steps", do: {:steps, 100_000}, else: {:stack, 4096}

        unless number in 1..maximum,
          do: fail("vm: value out of range for '#{option}': '#{value}'", 2)

        scan(tail, Map.put(options, key, number), [option | seen])
    end
  end

  defp scan([token | rest], options, seen) do
    if String.starts_with?(token, "-") and token != "-",
      do: fail("vm: unknown option '#{token}'", 2)

    if options.path != nil, do: fail("vm: expected at most one input path", 2)
    scan(rest, %{options | path: token}, seen)
  end
end
