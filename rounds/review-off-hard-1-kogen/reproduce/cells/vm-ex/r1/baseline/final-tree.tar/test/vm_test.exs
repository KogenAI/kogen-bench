defmodule Kogen.VMTest do
  use ExUnit.Case, async: true
  alias Kogen.VM

  defp fails(source, message, steps \\ 10000, stack \\ 256) do
    assert_raise Kogen.Error, "vm:" <> message, fn -> VM.run(source, steps, stack) end
  end

  test "arithmetic is exact, ordered, and truncates toward zero" do
    for {op, left, right, answer} <- [
          {"ADD", 4, 5, 9},
          {"SUB", 8, 3, 5},
          {"MUL", -7, 3, -21},
          {"DIV", -7, 3, -2},
          {"DIV", 7, -3, -2},
          {"DIV", -7, -3, 2},
          {"MOD", -7, 3, -1},
          {"MOD", 7, -3, 1},
          {"MOD", -7, -3, -1}
        ] do
      assert VM.run("PUSH #{left}\nPUSH #{right}\n#{op}\nOUT") == "#{answer}\n"
    end

    for {op, a, b} <- [
          {"ADD", 999_999_999, 1},
          {"SUB", -999_999_999, 1},
          {"MUL", 999_999_999, 999_999_999}
        ] do
      fails("PUSH #{a}\nPUSH #{b}\n#{op}", "3:1: integer overflow")
    end

    for op <- ["DIV", "MOD"] do
      fails("PUSH 7\nOUT\nPUSH 1\nPUSH 0\n#{op}", "5:1: division by zero")
      fails("PUSH 0\n#{op}", "2:1: stack underflow")
    end
  end

  test "integer grammar and inclusive boundaries" do
    for token <- ["-999999999", "999999999", "-999999998", "999999998", "+0000", "-0"] do
      assert VM.run("PUSH #{token}\nOUT") == "#{String.to_integer(token)}\n"
    end

    for token <- ["-1000000000", "1000000000"] do
      fails("  PUSH #{token}", "1:8: integer out of range")
    end

    for token <- ["+", "-", "1.0", "4#note", "--1"] do
      fails("  PUSH #{token}", "1:8: invalid integer")
    end
  end

  test "stack transitions, underflow and overflow" do
    assert VM.run("PUSH 1\nDUP\nPUSH 2\nSWAP\nOUT\nDROP\nOUT") == "1\n1\n"

    for op <- ["DUP", "DROP", "SWAP", "ADD", "SUB", "MUL", "DIV", "MOD", "OUT", "JZ end"] do
      fails("  #{op}\nend:", "1:3: stack underflow")
    end

    for op <- ["SWAP", "ADD", "SUB", "MUL", "DIV", "MOD"] do
      fails("PUSH 1\n#{op}", "2:1: stack underflow")
    end

    assert VM.run("PUSH 1\nOUT", 2, 1) == "1\n"
    fails("PUSH 1\nDUP", "2:1: stack overflow", 2, 1)
    fails("PUSH 1\nPUSH 2", "2:1: stack overflow", 2, 1)
    assert VM.run(String.duplicate("PUSH 1\n", 256)) == ""
    fails(String.duplicate("PUSH 1\n", 257), "257:1: stack overflow")
  end

  test "jumps, HALT, fallthrough and step boundaries" do
    assert VM.run("JMP end\nPUSH 7\nOUT\nend:", 1) == ""
    assert VM.run("PUSH 1\nJZ end\nPUSH 4\nOUT\nend:") == "4\n"
    assert VM.run("PUSH 0\nJZ end\nPUSH 4\nOUT\nend:") == ""
    assert VM.run("HALT\nOUT", 1) == ""
    assert VM.run("PUSH 1\nOUT", 2) == "1\n"
    fails("PUSH 1\nOUT", "2:1: step limit exceeded", 1)
    fails("again:\n  JMP again", "2:3: step limit exceeded", 3)
    fails("HALT\nBOGUS", "2:1: unknown instruction")
    fails("HALT\nJMP missing", "2:5: unknown label")
    fails("JMP absent\nsame:\nsame:", "3:1: duplicate label")
    fails("same:\nsame:\nBOGUS", "3:1: unknown instruction")
  end

  test "source grammar, comments, tabs, normalization and columns" do
    assert VM.run("\t# comment\t\r\n \t \r\n  PUSH +004 # note\r\nOUT\r\n\r") == "4\n"
    assert VM.run("JMP a123456789012345\na123456789012345:\n", 1) == ""
  end

  @tag timeout: 5_000
  test "maximum-size source with leading spaces and a comment parses promptly" do
    suffix = "PUSH 1 # note\nOUT"
    source = String.duplicate(" ", 1_048_576 - byte_size(suffix)) <> suffix
    assert VM.run(source) == "1\n"
  end

  test "syntax diagnostics in source order" do
    for {source, message} <- [
          {"  push 1", "1:3: unknown instruction"},
          {" PUSH", "1:2: wrong operand count"},
          {"DUP 1", "1:1: wrong operand count"},
          {"  a: extra", "1:3: wrong operand count"},
          {"  Bad:", "1:3: invalid label"},
          {"a1234567890123456:", "1:1: invalid label"},
          {"JMP Bad", "1:5: invalid label"},
          {"JMP a1234567890123456", "1:5: invalid label"},
          {"PUSH 1 # tab\t", "1:13: tab is not allowed"},
          {" \tBOGUS", "1:2: tab is not allowed"},
          {"BOGUS\n" <> <<255>>, "2:1: expected ASCII"},
          {"BOGUS\r\n a" <> <<255>>, "2:3: expected ASCII"},
          {"JMP missing\nJZ absent", "1:5: unknown label"}
        ] do
      fails(source, message)
    end
  end

  test "byte and record limits precede other parsing" do
    assert VM.run("#" <> String.duplicate("x", 1_048_575)) == ""
    fails("#" <> String.duplicate("x", 1_048_576), " input too large")
    assert VM.run(String.duplicate("HALT\n", 10000)) == ""
    assert VM.run(String.duplicate("HALT\n", 9999) <> "end:\n# ignored\n\t") == ""
    fails(String.duplicate("HALT\n", 10000) <> "\tBOGUS", "10001:1: too many records")
  end
end
