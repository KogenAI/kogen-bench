defmodule Kogen.CLITest do
  use ExUnit.Case, async: true

  test "options accept decimal boundaries and leading zeroes" do
    for value <- ["1", "2", "99999", "100000", "0001"] do
      assert Kogen.Core.options(["--steps", value]).steps == String.to_integer(value)
    end

    for value <- ["1", "2", "4095", "4096", "0001"] do
      assert Kogen.Core.options(["--stack", value]).stack == String.to_integer(value)
    end

    assert Kogen.Core.options([]) == %{steps: 10000, stack: 256, path: nil}
    assert Kogen.Core.options(["-", "--stack", "1"]).path == "-"
  end

  test "argument errors stop at the first error with exit code two" do
    for option <- ["--steps", "--stack"] do
      maximum = if option == "--steps", do: 100_000, else: 4096

      cases =
        [
          {[option], "option '#{option}' requires a value"},
          {[option, "1", option], "duplicate option '#{option}'"},
          {[option, "1", option, "bad"], "duplicate option '#{option}'"}
        ] ++
          Enum.map(["", "-1", "+1", "1.0", "--help", "١"], fn value ->
            {[option, value], "invalid value for '#{option}': '#{value}'"}
          end) ++
          Enum.map(["0", "#{maximum + 1}"], fn value ->
            {[option, value], "value out of range for '#{option}': '#{value}'"}
          end)

      for {args, message} <- cases do
        error = assert_raise Kogen.Error, "vm: " <> message, fn -> Kogen.Core.execute(args) end
        assert error.code == 2
      end
    end

    for {args, message} <- [
          {["--help", "file"], "unknown option '--help'"},
          {["--wat", "--steps"], "unknown option '--wat'"},
          {["a", "b", "--wat"], "expected at most one input path"}
        ] do
      error = assert_raise Kogen.Error, "vm: " <> message, fn -> Kogen.Core.execute(args) end
      assert error.code == 2
    end
  end

  test "file input is wired through parsing and execution" do
    path = Path.join(System.tmp_dir!(), "vm-#{System.unique_integer([:positive])}")
    on_exit(fn -> File.rm(path) end)
    File.write!(path, "PUSH 42\r\nOUT\r")
    assert Kogen.Core.execute([path]) == "42\n"
    File.rm!(path)
    assert_raise Kogen.Error, "vm: cannot read input", fn -> Kogen.Core.execute([path]) end
  end
end
