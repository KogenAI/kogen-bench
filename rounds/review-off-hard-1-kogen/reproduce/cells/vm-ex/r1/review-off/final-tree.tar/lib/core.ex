defmodule Kogen.Core do
  @moduledoc "Argument handling for the bounded stack machine."
  import Kogen.Input, only: [fail: 2]

  @help """
  Usage: kogen-vm [--steps N] [--stack N] [FILE|-]
  Run a bounded integer stack program.
  Options:
    --steps N    Maximum instructions executed (default 10000).
    --stack N    Maximum stack depth (default 256).
    --help       Show this help.
  """

  def execute(["--help"]), do: @help

  def execute(args) do
    options = arguments(args, %{steps: 10000, stack: 256, path: nil}, MapSet.new())
    options.path |> Kogen.Input.read("vm") |> Kogen.VM.run(options.steps, options.stack)
  end

  defp arguments([], options, _seen), do: options

  defp arguments([option | rest], options, seen) when option in ["--steps", "--stack"] do
    if MapSet.member?(seen, option), do: fail("vm: duplicate option '#{option}'", 2)

    case rest do
      [] ->
        fail("vm: option '#{option}' requires a value", 2)

      [value | tail] ->
        unless Regex.match?(~r/\A[0-9]+\z/, value),
          do: fail("vm: invalid value for '#{option}': '#{value}'", 2)

        number = String.to_integer(value)
        maximum = if option == "--steps", do: 100_000, else: 4096

        unless number in 1..maximum,
          do: fail("vm: value out of range for '#{option}': '#{value}'", 2)

        key = if option == "--steps", do: :steps, else: :stack
        arguments(tail, Map.put(options, key, number), MapSet.put(seen, option))
    end
  end

  defp arguments([token | rest], options, seen) do
    if token != "-" and String.starts_with?(token, "-"),
      do: fail("vm: unknown option '#{token}'", 2)

    if options.path != nil, do: fail("vm: expected at most one input path", 2)
    arguments(rest, %{options | path: token}, seen)
  end
end
