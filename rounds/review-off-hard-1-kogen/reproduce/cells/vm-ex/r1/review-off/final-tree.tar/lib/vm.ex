defmodule Kogen.VM do
  @moduledoc "Parse, resolve and execute bounded integer stack programs in process."
  import Kogen.Input, only: [fail: 1]
  @bound 999_999_999
  @operands %{
    "PUSH" => 1,
    "DUP" => 0,
    "DROP" => 0,
    "SWAP" => 0,
    "ADD" => 0,
    "SUB" => 0,
    "MUL" => 0,
    "DIV" => 0,
    "MOD" => 0,
    "OUT" => 0,
    "JMP" => 1,
    "JZ" => 1,
    "HALT" => 0
  }
  @required %{
    "DUP" => 1,
    "DROP" => 1,
    "SWAP" => 2,
    "ADD" => 2,
    "SUB" => 2,
    "MUL" => 2,
    "DIV" => 2,
    "MOD" => 2,
    "OUT" => 1,
    "JZ" => 1
  }

  @doc "Return all output on success, or raise Kogen.Error without partial output."
  def run(bytes, steps \\ 10000, stack_limit \\ 256) do
    if byte_size(bytes) > 1_048_576, do: fail("vm: input too large")
    lines = Kogen.Input.physical_lines(bytes)

    Enum.with_index(lines, 1)
    |> Enum.each(fn {line, number} ->
      case ascii_column(line, 1) do
        nil -> :ok
        col -> error(number, col, "expected ASCII")
      end
    end)

    {records, _} = Enum.map_reduce(Enum.with_index(lines, 1), 0, &record/2)
    records = Enum.reject(records, &is_nil/1)

    {labels, _, duplicates} =
      Enum.reduce(records, {%{}, 0, []}, fn
        {:label, name, line, col}, {labels, pc, duplicates} ->
          if Map.has_key?(labels, name) do
            {labels, pc, [{line, col} | duplicates]}
          else
            {Map.put(labels, name, pc), pc, duplicates}
          end

        _, {labels, pc, duplicates} ->
          {labels, pc + 1, duplicates}
      end)

    case Enum.reverse(duplicates) do
      [{line, col} | _] -> error(line, col, "duplicate label")
      [] -> :ok
    end

    program =
      records
      |> Enum.reject(&(elem(&1, 0) == :label))
      |> Enum.map(fn
        {op, target, line, col, operand_col} when op in ["JMP", "JZ"] ->
          case Map.fetch(labels, target) do
            {:ok, pc} -> {op, pc, line, col}
            :error -> error(line, operand_col, "unknown label")
          end

        {op, value, line, col, _} ->
          {op, value, line, col}
      end)
      |> List.to_tuple()

    execute(program, 0, [], 0, [], 0, steps, stack_limit)
  end

  defp ascii_column(<<>>, _), do: nil
  defp ascii_column(<<byte, _::binary>>, col) when byte > 127, do: col
  defp ascii_column(<<_, rest::binary>>, col), do: ascii_column(rest, col + 1)

  defp record({line, number}, count) do
    if Regex.match?(~r/\A[ \t]*(?:#.*)?\z/s, line) do
      {nil, count}
    else
      if count == 10000, do: error(number, 1, "too many records")

      case :binary.match(line, "\t") do
        {offset, _} -> error(number, offset + 1, "tab is not allowed")
        :nomatch -> :ok
      end

      # A suffix comment must start after a space; leading comments were ignored above.
      source = line |> String.replace(~r/ +#.*/s, "")

      tokens =
        Regex.scan(~r/[^ ]+/, source, return: :index)
        |> Enum.map(fn [{offset, size}] -> {binary_part(source, offset, size), offset + 1} end)

      {parse(tokens, number), count + 1}
    end
  end

  defp parse([{name, col} | args], line) do
    cond do
      String.ends_with?(name, ":") ->
        if args != [], do: error(line, col, "wrong operand count")

        unless Regex.match?(~r/\A[a-z][a-z0-9_]{0,15}:\z/, name),
          do: error(line, col, "invalid label")

        {:label, String.trim_trailing(name, ":"), line, col}

      not Map.has_key?(@operands, name) ->
        error(line, col, "unknown instruction")

      length(args) != @operands[name] ->
        error(line, col, "wrong operand count")

      name == "PUSH" ->
        [{value, operand_col}] = args

        unless Regex.match?(~r/\A[+-]?[0-9]+\z/, value),
          do: error(line, operand_col, "invalid integer")

        integer = String.to_integer(value)
        unless integer in -@bound..@bound, do: error(line, operand_col, "integer out of range")
        {name, integer, line, col, operand_col}

      name in ["JMP", "JZ"] ->
        [{target, operand_col}] = args

        unless Regex.match?(~r/\A[a-z][a-z0-9_]{0,15}\z/, target),
          do: error(line, operand_col, "invalid label")

        {name, target, line, col, operand_col}

      true ->
        {name, nil, line, col, nil}
    end
  end

  defp execute(program, pc, stack, depth, output, used, steps, limit) do
    if pc == tuple_size(program) do
      output |> Enum.reverse() |> IO.iodata_to_binary()
    else
      {op, value, line, col} = elem(program, pc)
      if used == steps, do: error(line, col, "step limit exceeded")
      if depth < Map.get(@required, op, 0), do: error(line, col, "stack underflow")
      if op in ["PUSH", "DUP"] and depth == limit, do: error(line, col, "stack overflow")

      case op do
        "HALT" ->
          output |> Enum.reverse() |> IO.iodata_to_binary()

        "PUSH" ->
          execute(program, pc + 1, [value | stack], depth + 1, output, used + 1, steps, limit)

        "DUP" ->
          execute(program, pc + 1, [hd(stack) | stack], depth + 1, output, used + 1, steps, limit)

        "DROP" ->
          execute(program, pc + 1, tl(stack), depth - 1, output, used + 1, steps, limit)

        "OUT" ->
          execute(
            program,
            pc + 1,
            tl(stack),
            depth - 1,
            [Integer.to_string(hd(stack)) <> "\n" | output],
            used + 1,
            steps,
            limit
          )

        "SWAP" ->
          [right, left | tail] = stack
          execute(program, pc + 1, [left, right | tail], depth, output, used + 1, steps, limit)

        "JMP" ->
          execute(program, value, stack, depth, output, used + 1, steps, limit)

        "JZ" ->
          [top | tail] = stack
          next = if top == 0, do: value, else: pc + 1
          execute(program, next, tail, depth - 1, output, used + 1, steps, limit)

        arithmetic ->
          [right, left | tail] = stack
          if arithmetic in ["DIV", "MOD"] and right == 0, do: error(line, col, "division by zero")

          result =
            case arithmetic do
              "ADD" -> left + right
              "SUB" -> left - right
              "MUL" -> left * right
              "DIV" -> div(left, right)
              "MOD" -> rem(left, right)
            end

          unless result in -@bound..@bound, do: error(line, col, "integer overflow")
          execute(program, pc + 1, [result | tail], depth - 1, output, used + 1, steps, limit)
      end
    end
  end

  defp error(line, col, message), do: fail("vm:#{line}:#{col}: #{message}")
end
