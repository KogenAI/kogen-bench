defmodule Kogen.CLITest do
  use ExUnit.Case

  setup_all do
    Mix.Task.run("escript.build")
    :ok
  end

  defp cli(args) do
    System.cmd(Path.expand("run"), args, stderr_to_stdout: true)
  end

  test "sole help has exact output without opening input" do
    assert cli(["--help"]) ==
             {"""
              Usage: kogen-vm [--steps N] [--stack N] [FILE|-]
              Run a bounded integer stack program.
              Options:
                --steps N    Maximum instructions executed (default 10000).
                --stack N    Maximum stack depth (default 256).
                --help       Show this help.
              """, 0}
  end

  test "arguments are validated left to right before input is opened" do
    for {args, message} <- [
          {["--steps"], "option '--steps' requires a value"},
          {["--stack"], "option '--stack' requires a value"},
          {["--steps", "1", "--steps"], "duplicate option '--steps'"},
          {["--stack", "1", "--stack", "bad"], "duplicate option '--stack'"},
          {["--steps", "--stack"], "invalid value for '--steps': '--stack'"},
          {["--stack", "+1"], "invalid value for '--stack': '+1'"},
          {["--steps", ""], "invalid value for '--steps': ''"},
          {["--steps", "0"], "value out of range for '--steps': '0'"},
          {["--steps", "100001"], "value out of range for '--steps': '100001'"},
          {["--stack", "0"], "value out of range for '--stack': '0'"},
          {["--stack", "4097"], "value out of range for '--stack': '4097'"},
          {["--help", "x"], "unknown option '--help'"},
          {["missing", "other"], "expected at most one input path"},
          {["missing", "--bad"], "unknown option '--bad'"}
        ] do
      assert cli(args) == {"vm: #{message}\n", 2}
    end
  end

  test "file input, option boundaries and read failures" do
    path = Path.join(System.tmp_dir!(), "vm-#{System.unique_integer([:positive])}")
    File.write!(path, "PUSH 42\nOUT\n")
    on_exit(fn -> File.rm(path) end)
    assert cli([path, "--steps", "0002", "--stack", "0001"]) == {"42\n", 0}
    assert cli(["--steps", "100000", "--stack", "4096", path]) == {"42\n", 0}
    assert cli([path <> "-absent"]) == {"vm: cannot read input\n", 1}
  end
end
