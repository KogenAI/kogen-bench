defmodule Kogen.VMTest do
  use ExUnit.Case, async: true
  alias Kogen.VM

  defp fails(source, message, steps \\ 10000, stack \\ 256) do
    assert_raise Kogen.Error, message, fn -> VM.run(source, steps, stack) end
  end

  test "arithmetic is exact and ordered, with signed division and remainder" do
    for {op, left, right, result} <- [
          {"ADD", 2, 3, 5},
          {"SUB", 8, 3, 5},
          {"MUL", -3, 4, -12},
          {"DIV", -7, 3, -2},
          {"DIV", 7, -3, -2},
          {"MOD", -7, 3, -1},
          {"MOD", 7, -3, 1}
        ] do
      assert VM.run("PUSH #{left}\nPUSH #{right}\n#{op}\nOUT") == "#{result}\n"
    end

    assert VM.run("PUSH +000\nOUT\nPUSH -999999999\nOUT\nPUSH 999999999\nOUT") ==
             "0\n-999999999\n999999999\n"

    for op <- ["ADD", "SUB", "MUL"] do
      right = if op == "SUB", do: -2, else: 2
      fails("PUSH 999999999\nPUSH #{right}\n#{op}", "vm:3:1: integer overflow")
    end

    for op <- ["DIV", "MOD"] do
      fails("PUSH 1\nPUSH 0\n#{op}", "vm:3:1: division by zero")
      fails("PUSH 0\n#{op}", "vm:2:1: stack underflow")
    end
  end

  test "stack transitions and conditional and unconditional jumps" do
    assert VM.run("PUSH 1\nDUP\nPUSH 2\nSWAP\nOUT\nDROP\nOUT") == "1\n1\n"

    for {condition, output} <- [{0, "4\n"}, {1, "9\n4\n"}] do
      assert VM.run("PUSH #{condition}\nJZ yes\nPUSH 9\nOUT\nyes:\nPUSH 4\nOUT") == output
    end

    assert VM.run("JMP end\nPUSH 9\nOUT\nend:") == ""
    assert VM.run("HALT\nOUT", 1) == ""
    assert VM.run("PUSH 1\nOUT", 2) == "1\n"
    fails("PUSH 1\nOUT", "vm:2:1: step limit exceeded", 1)
    fails("loop:\nJMP loop", "vm:2:1: step limit exceeded", 3)
    assert VM.run("PUSH 1\nOUT", 2, 1) == "1\n"
    fails("PUSH 1\nPUSH 2", "vm:2:1: stack overflow", 10, 1)
    fails("PUSH 1\nDUP", "vm:2:1: stack overflow", 10, 1)

    for op <- ~w(DUP DROP SWAP ADD SUB MUL DIV MOD OUT JZ) do
      instruction = if op == "JZ", do: "JZ end\nend:", else: op
      fails(instruction, "vm:1:1: stack underflow")
    end

    fails("PUSH 7\nOUT\nDROP", "vm:3:1: stack underflow")
  end

  test "source normalization, comments, columns and syntax errors" do
    assert VM.run("\t # ignored\r\n \t\r\n  PUSH +004 # note\r\n OUT\r") == "4\n"

    for {source, diagnostic} <- [
          {"  WHAT", "1:3: unknown instruction"},
          {"PUSH 4#note", "1:6: invalid integer"},
          {"PUSH", "1:1: wrong operand count"},
          {"OUT 1", "1:1: wrong operand count"},
          {"  x: extra", "1:3: wrong operand count"},
          {"Bad:", "1:1: invalid label"},
          {"JMP Bad", "1:5: invalid label"},
          {"PUSH +", "1:6: invalid integer"},
          {"PUSH 1000000000", "1:6: integer out of range"},
          {"PUSH -1000000000", "1:6: integer out of range"},
          {"  PUSH\t1", "1:7: tab is not allowed"},
          {"OUT # note\t", "1:11: tab is not allowed"},
          {"HALT\nBOGUS", "2:1: unknown instruction"},
          {"BOGUS\na" <> <<255>>, "2:2: expected ASCII"}
        ] do
      fails(source, "vm:" <> diagnostic)
    end
  end

  test "syntax precedes duplicate labels which precede unresolved labels" do
    fails("JMP absent\nsame:\nsame:\nBOGUS", "vm:4:1: unknown instruction")
    fails("JMP absent\nsame:\n same:", "vm:3:2: duplicate label")
    fails("HALT\n JMP absent", "vm:2:6: unknown label")
  end

  test "record and byte limits include their valid boundaries" do
    assert VM.run(String.duplicate("x", 0)) == ""
    assert VM.run(String.duplicate("HALT\n", 10000)) == ""

    fails(
      String.duplicate("HALT\n", 10000) <> "\n# ignored\nBAD\t",
      "vm:10003:1: too many records"
    )

    assert VM.run("#" <> String.duplicate("x", 1_048_575)) == ""
    fails("#" <> String.duplicate("x", 1_048_576), "vm: input too large")
  end
end
