package main

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

const usage = "Usage: kogen-vm [--steps N] [--stack N] [FILE|-]\nRun a bounded integer stack program.\nOptions:\n  --steps N    Maximum instructions executed (default 10000).\n  --stack N    Maximum stack depth (default 256).\n  --help       Show this help.\n"
const maxInput = 1048576
const maxInteger int64 = 999999999

func execute(args []string) (string, int, error) {
	if len(args) == 1 && args[0] == "--help" {
		return usage, 0, nil
	}
	steps, stack := 10000, 256
	seen := map[string]bool{}
	path, hasPath := "", false
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "--steps" || arg == "--stack" {
			if seen[arg] {
				return "", 2, fmt.Errorf("vm: duplicate option '%s'", arg)
			}
			seen[arg] = true
			if i+1 == len(args) {
				return "", 2, fmt.Errorf("vm: option '%s' requires a value", arg)
			}
			i++
			value := args[i]
			if !digits.MatchString(value) {
				return "", 2, fmt.Errorf("vm: invalid value for '%s': '%s'", arg, value)
			}
			n, err := strconv.ParseUint(value, 10, 64)
			limit := uint64(100000)
			if arg == "--stack" {
				limit = 4096
			}
			if err != nil || n < 1 || n > limit {
				return "", 2, fmt.Errorf("vm: value out of range for '%s': '%s'", arg, value)
			}
			if arg == "--steps" {
				steps = int(n)
			} else {
				stack = int(n)
			}
		} else if strings.HasPrefix(arg, "-") && arg != "-" {
			return "", 2, fmt.Errorf("vm: unknown option '%s'", arg)
		} else {
			if hasPath {
				return "", 2, fmt.Errorf("vm: expected at most one input path")
			}
			path, hasPath = arg, true
		}
	}
	data, err := Load(path, hasPath, "vm")
	if err != nil {
		return "", 1, err
	}
	out, err := runProgram(data, steps, stack)
	if err != nil {
		return "", 1, err
	}
	return out, 0, nil
}

var digits = regexp.MustCompile(`^[0-9]+$`)
var integer = regexp.MustCompile(`^[+-]?[0-9]+$`)
var label = regexp.MustCompile(`^[a-z][a-z0-9_]{0,15}$`)
var operands = map[string]int{"PUSH": 1, "DUP": 0, "DROP": 0, "SWAP": 0, "ADD": 0, "SUB": 0, "MUL": 0, "DIV": 0, "MOD": 0, "OUT": 0, "JMP": 1, "JZ": 1, "HALT": 0}

type instruction struct {
	op, target                         string
	value                              int64
	line, col, operandCol, destination int
}
type labelRecord struct {
	name                string
	position, line, col int
}

func diagnostic(line, col int, message string) error {
	return fmt.Errorf("vm:%d:%d: %s", line, col, message)
}

func parse(data []byte) ([]instruction, error) {
	if len(data) > maxInput {
		return nil, fmt.Errorf("vm: input too large")
	}
	lines := physicalLines(data)
	for i, line := range lines {
		for j := 0; j < len(line); j++ {
			if line[j] > 127 {
				return nil, diagnostic(i+1, j+1, "expected ASCII")
			}
		}
	}
	var code []instruction
	var labels []labelRecord
	records := 0
	for i, line := range lines {
		trimmed := strings.Trim(line, " \t")
		if trimmed == "" || strings.HasPrefix(trimmed, "#") {
			continue
		}
		if records == 10000 {
			return nil, diagnostic(i+1, 1, "too many records")
		}
		records++
		if j := strings.IndexByte(line, '\t'); j >= 0 {
			return nil, diagnostic(i+1, j+1, "tab is not allowed")
		}
		for j := 0; j < len(line); j++ {
			if line[j] == '#' && (j == 0 || line[j-1] == ' ') {
				line = line[:j]
				break
			}
		}
		text := strings.Trim(line, " ")
		tokens := strings.FieldsFunc(text, func(r rune) bool { return r == ' ' })
		col := len(line) - len(strings.TrimLeft(line, " ")) + 1
		first := tokens[0]
		fail := func(message string) ([]instruction, error) { return nil, diagnostic(i+1, col, message) }
		if strings.HasSuffix(first, ":") {
			if len(tokens) != 1 {
				return fail("wrong operand count")
			}
			name := strings.TrimSuffix(first, ":")
			if !label.MatchString(name) {
				return fail("invalid label")
			}
			labels = append(labels, labelRecord{name, len(code), i + 1, col})
			continue
		}
		count, ok := operands[first]
		if !ok {
			return fail("unknown instruction")
		}
		if len(tokens) != count+1 {
			return fail("wrong operand count")
		}
		ins := instruction{op: first, line: i + 1, col: col}
		if count == 1 {
			ins.operandCol = col + len(first) + len(text[len(first):]) - len(strings.TrimLeft(text[len(first):], " "))
			operand := tokens[1]
			if first == "PUSH" {
				if !integer.MatchString(operand) {
					return nil, diagnostic(i+1, ins.operandCol, "invalid integer")
				}
				value, err := strconv.ParseInt(operand, 10, 64)
				if err != nil || value < -maxInteger || value > maxInteger {
					return nil, diagnostic(i+1, ins.operandCol, "integer out of range")
				}
				ins.value = value
			} else {
				if !label.MatchString(operand) {
					return nil, diagnostic(i+1, ins.operandCol, "invalid label")
				}
				ins.target = operand
			}
		}
		code = append(code, ins)
	}
	positions := map[string]int{}
	for _, l := range labels {
		if _, ok := positions[l.name]; ok {
			return nil, diagnostic(l.line, l.col, "duplicate label")
		}
		positions[l.name] = l.position
	}
	for i := range code {
		if code[i].op == "JMP" || code[i].op == "JZ" {
			p, ok := positions[code[i].target]
			if !ok {
				return nil, diagnostic(code[i].line, code[i].operandCol, "unknown label")
			}
			code[i].destination = p
		}
	}
	return code, nil
}

func runProgram(data []byte, steps, limit int) (string, error) {
	code, err := parse(data)
	if err != nil {
		return "", err
	}
	var stack []int64
	var output strings.Builder
	pc, executed := 0, 0
	for pc < len(code) {
		ins := code[pc]
		fail := func(message string) (string, error) { return "", diagnostic(ins.line, ins.col, message) }
		if executed == steps {
			return fail("step limit exceeded")
		}
		executed++
		need := 0
		switch ins.op {
		case "DUP", "DROP", "OUT", "JZ":
			need = 1
		case "SWAP", "ADD", "SUB", "MUL", "DIV", "MOD":
			need = 2
		}
		if len(stack) < need {
			return fail("stack underflow")
		}
		if (ins.op == "PUSH" || ins.op == "DUP") && len(stack) == limit {
			return fail("stack overflow")
		}
		pc++
		n := len(stack)
		switch ins.op {
		case "PUSH":
			stack = append(stack, ins.value)
		case "DUP":
			stack = append(stack, stack[n-1])
		case "DROP":
			stack = stack[:n-1]
		case "SWAP":
			stack[n-1], stack[n-2] = stack[n-2], stack[n-1]
		case "OUT":
			fmt.Fprintf(&output, "%d\n", stack[n-1])
			stack = stack[:n-1]
		case "JMP":
			pc = ins.destination
		case "JZ":
			if stack[n-1] == 0 {
				pc = ins.destination
			}
			stack = stack[:n-1]
		case "HALT":
			return output.String(), nil
		default:
			left, right := stack[n-2], stack[n-1]
			var result int64
			switch ins.op {
			case "ADD":
				result = left + right
			case "SUB":
				result = left - right
			case "MUL":
				result = left * right
			case "DIV", "MOD":
				if right == 0 {
					return fail("division by zero")
				}
				if ins.op == "DIV" {
					result = left / right
				} else {
					result = left % right
				}
			}
			if result < -maxInteger || result > maxInteger {
				return fail("integer overflow")
			}
			stack = append(stack[:n-2], result)
		}
	}
	return output.String(), nil
}
