package main

import (
	"bytes"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestCLI(t *testing.T) {
	binary := filepath.Join(t.TempDir(), "kogen-vm")
	if output, err := exec.Command("go", "build", "-o", binary, ".").CombinedOutput(); err != nil {
		t.Fatalf("build: %v: %s", err, output)
	}
	type cliCase struct {
		args            []string
		input, out, err string
		code            int
	}
	cases := []cliCase{
		{[]string{"--help"}, "invalid", usage, "", 0},
		{nil, "PUSH 2\nOUT", "2\n", "", 0},
		{[]string{"-"}, "PUSH 3\nOUT", "3\n", "", 0},
		{[]string{"--steps", "00002", "--stack", "0001"}, "PUSH 1\nOUT", "1\n", "", 0},
		{[]string{"--help", "-"}, "", "", "vm: unknown option '--help'\n", 2},
		{[]string{"--bad"}, "", "", "vm: unknown option '--bad'\n", 2},
		{[]string{"one", "two", "--bad"}, "", "", "vm: expected at most one input path\n", 2},
		{[]string{"--steps", "0", "--bad"}, "", "", "vm: value out of range for '--steps': '0'\n", 2},
	}
	for _, option := range []string{"--steps", "--stack"} {
		cases = append(cases, cliCase{[]string{option}, "", "", "vm: option '" + option + "' requires a value\n", 2})
		for _, suffix := range [][]string{{option}, {option, "bad"}} {
			args := append([]string{option, "1"}, suffix...)
			cases = append(cases, cliCase{args, "", "", "vm: duplicate option '" + option + "'\n", 2})
		}
		for _, value := range []string{"", "-1", "+1", "1.0", "--help", "\xff"} {
			cases = append(cases, cliCase{[]string{option, value}, "", "", "vm: invalid value for '" + option + "': '" + value + "'\n", 2})
		}
		max, above := "100000", "100001"
		if option == "--stack" {
			max, above = "4096", "4097"
		}
		for _, value := range []string{"1", max} {
			cases = append(cases, cliCase{[]string{option, value}, "HALT", "", "", 0})
		}
		for _, value := range []string{"0", above, strings.Repeat("9", 30)} {
			cases = append(cases, cliCase{[]string{option, value}, "", "", "vm: value out of range for '" + option + "': '" + value + "'\n", 2})
		}
	}
	file := filepath.Join(t.TempDir(), "source")
	if err := os.WriteFile(file, []byte("PUSH 4\nOUT"), 0600); err != nil {
		t.Fatal(err)
	}
	cases = append(cases, cliCase{[]string{file}, "invalid", "4\n", "", 0}, cliCase{[]string{file + "missing"}, "", "", "vm: cannot read input\n", 1})
	for _, tc := range cases {
		t.Run(strings.Join(tc.args, " "), func(t *testing.T) {
			cmd := exec.Command(binary, tc.args...)
			cmd.Stdin = strings.NewReader(tc.input)
			var out, stderr bytes.Buffer
			cmd.Stdout = &out
			cmd.Stderr = &stderr
			err := cmd.Run()
			code := 0
			if err != nil {
				exit, ok := err.(*exec.ExitError)
				if !ok {
					t.Fatal(err)
				}
				code = exit.ExitCode()
			}
			if code != tc.code || out.String() != tc.out || stderr.String() != tc.err {
				t.Fatalf("got exit %d stdout %q stderr %q; want %d %q %q", code, out.String(), stderr.String(), tc.code, tc.out, tc.err)
			}
		})
	}
	// Keep stdin open without sending data: help and argument errors must not read it.
	for _, args := range [][]string{{"--help"}, {"--bad"}} {
		cmd := exec.Command(binary, args...)
		stdin, err := cmd.StdinPipe()
		if err != nil {
			t.Fatal(err)
		}
		if err := cmd.Start(); err != nil {
			t.Fatal(err)
		}
		done := make(chan error, 1)
		go func() { done <- cmd.Wait() }()
		select {
		case <-done:
		case <-time.After(5 * time.Second):
			_ = cmd.Process.Kill()
			<-done
			t.Fatal("command read input before handling arguments")
		}
		_ = stdin.Close()
	}
}
