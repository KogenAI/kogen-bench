package main

import (
	"fmt"
	"strings"
	"testing"
)

func TestPrograms(t *testing.T) {
	cases := []struct{ name, source, want string }{
		{"empty", "", ""},
		{"ignored", " \t\n\t# comment\t\n", ""},
		{"arithmetic", "PUSH 8\nPUSH 3\nSUB\nOUT\nPUSH -7\nPUSH 3\nDIV\nOUT\nPUSH -7\nPUSH 3\nMOD\nOUT", "5\n-2\n-1\n"},
		{"signs", "PUSH 7\nPUSH -3\nDIV\nOUT\nPUSH 7\nPUSH -3\nMOD\nOUT\nPUSH -7\nPUSH -3\nDIV\nOUT", "-2\n1\n2\n"},
		{"stack operations", "PUSH 2\nDUP\nADD\nPUSH 3\nSWAP\nMUL\nDUP\nDROP\nOUT", "12\n"},
		{"integers and comments", "  PUSH +000999999999 # note\r\nOUT\r\nPUSH -999999999\nOUT\nPUSH -0\nOUT\r", "999999999\n-999999999\n0\n"},
		{"zero jump", "PUSH 0\nJZ yes\nPUSH 99\nOUT\nyes:\nPUSH 4\nOUT", "4\n"},
		{"nonzero jump", "PUSH 1\nJZ end\nPUSH 5\nOUT\nJMP end\nDROP\nend:", "5\n"},
		{"halt", "PUSH 7\nOUT\nHALT\nDROP", "7\n"},
		{"aliases", "a:\nb:\nJMP end\nend:", ""},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			out, err := runProgram([]byte(tc.source), 10000, 256)
			if err != nil || out != tc.want {
				t.Fatalf("got %q, %v; want %q", out, err, tc.want)
			}
		})
	}
}

func TestSourceErrors(t *testing.T) {
	cases := []struct{ source, want string }{
		{"BOGUS\na\xff\n", "2:2: expected ASCII"},
		{"#\xff", "1:2: expected ASCII"},
		{"BOGUS\r\n \xff", "2:2: expected ASCII"},
		{"PUSH\t1", "1:5: tab is not allowed"},
		{"PUSH 1 #\t", "1:9: tab is not allowed"},
		{"PUSH 4#note", "1:6: invalid integer"},
		{"  bogus", "1:3: unknown instruction"},
		{"PUSH", "1:1: wrong operand count"},
		{"OUT 1", "1:1: wrong operand count"},
		{"a: extra", "1:1: wrong operand count"},
		{"A:", "1:1: invalid label"},
		{"abcdefghijklmnopq:", "1:1: invalid label"},
		{"JMP A", "1:5: invalid label"},
		{"  JZ   a:", "1:8: invalid label"},
		{"PUSH +", "1:6: invalid integer"},
		{"PUSH 1.0", "1:6: invalid integer"},
		{" PUSH   1000000000", "1:9: integer out of range"},
		{"PUSH -1000000000", "1:6: integer out of range"},
		{"PUSH 999999999999999999999999999999", "1:6: integer out of range"},
		{"HALT\nBOGUS", "2:1: unknown instruction"},
		{"a:\na:\nBOGUS", "3:1: unknown instruction"},
		{"JMP missing\na:\na:", "3:1: duplicate label"},
		{"HALT\n  JMP missing\nJZ other", "2:7: unknown label"},
		{"PUSH 1\rOUT", "1:6: invalid integer"},
	}
	for _, tc := range cases {
		t.Run(tc.want+tc.source, func(t *testing.T) {
			out, err := runProgram([]byte(tc.source), 10000, 256)
			if err == nil || err.Error() != "vm:"+tc.want || out != "" {
				t.Fatalf("got %q, %v; want vm:%s", out, err, tc.want)
			}
		})
	}
}

func TestRuntimeErrors(t *testing.T) {
	for _, op := range []string{"DUP", "DROP", "OUT", "JZ end", "SWAP", "ADD", "SUB", "MUL", "DIV", "MOD"} {
		t.Run(op, func(t *testing.T) {
			_, err := runProgram([]byte("  "+op+"\nend:"), 10, 1)
			if err == nil || err.Error() != "vm:1:3: stack underflow" {
				t.Fatal(err)
			}
		})
	}
	cases := []struct {
		source       string
		steps, stack int
		want         string
	}{
		{"PUSH 1\n  PUSH 2", 10, 1, "2:3: stack overflow"},
		{"PUSH 1\nDUP", 10, 1, "2:1: stack overflow"},
		{"PUSH 7\nOUT\nPUSH 0\nDIV", 10, 2, "4:1: stack underflow"},
		{"PUSH 7\nOUT\nPUSH 1\nPUSH 0\nDIV", 10, 2, "5:1: division by zero"},
		{"PUSH 1\nPUSH 0\nMOD", 10, 2, "3:1: division by zero"},
		{"PUSH 999999999\nPUSH 1\nADD", 10, 2, "3:1: integer overflow"},
		{"PUSH -999999999\nPUSH 1\nSUB", 10, 2, "3:1: integer overflow"},
		{"PUSH 999999999\nDUP\nMUL", 10, 2, "3:1: integer overflow"},
		{"PUSH 1\nOUT", 1, 1, "2:1: step limit exceeded"},
		{"loop:\n  JMP loop", 3, 1, "2:3: step limit exceeded"},
	}
	for _, tc := range cases {
		t.Run(tc.want, func(t *testing.T) {
			out, err := runProgram([]byte(tc.source), tc.steps, tc.stack)
			if out != "" || err == nil || err.Error() != "vm:"+tc.want {
				t.Fatalf("got %q, %v", out, err)
			}
		})
	}
	for _, source := range []string{"HALT\nDROP", "PUSH 1", "JMP end\nend:"} {
		if _, err := runProgram([]byte(source), 1, 1); err != nil {
			t.Fatal(err)
		}
	}
}

func TestSourceLimits(t *testing.T) {
	for _, size := range []int{maxInput - 1, maxInput, maxInput + 1} {
		_, err := runProgram([]byte(strings.Repeat(" ", size)), 1, 1)
		if size <= maxInput && err != nil {
			t.Fatal(err)
		}
		if size > maxInput && (err == nil || err.Error() != "vm: input too large") {
			t.Fatal(err)
		}
	}
	for _, n := range []int{9999, 10000, 10001} {
		source := strings.Repeat("HALT\n", n)
		_, err := runProgram([]byte(source), 1, 1)
		if n <= 10000 && err != nil {
			t.Fatal(err)
		}
		if n > 10000 && (err == nil || err.Error() != "vm:10001:1: too many records") {
			t.Fatal(err)
		}
	}
	source := strings.Repeat("HALT\n", 10000) + "\t# ignored\n \tbad"
	_, err := runProgram([]byte(source), 1, 1)
	if err == nil || err.Error() != "vm:10002:1: too many records" {
		t.Fatal(err)
	}
	// Label records count even though they do not execute.
	var b strings.Builder
	for i := 0; i < 10000; i++ {
		fmt.Fprintf(&b, "a%d:\n", i)
	}
	b.WriteString("HALT")
	_, err = runProgram([]byte(b.String()), 1, 1)
	if err == nil || err.Error() != "vm:10001:1: too many records" {
		t.Fatal(err)
	}
}
