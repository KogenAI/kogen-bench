package main

import (
	"fmt"
	"strconv"
	"strings"
)

const maxInteger int64 = 999999999
const maxInput = 1048576

type instruction struct {
	op                    string
	value                 int64
	target                string
	dest                  int
	line, col, operandCol int
}

type label struct {
	name            string
	dest, line, col int
}

func sourceError(line, col int, message string) error {
	return fmt.Errorf("vm:%d:%d: %s", line, col, message)
}

func validLabel(s string) bool {
	if len(s) < 1 || len(s) > 16 || s[0] < 'a' || s[0] > 'z' {
		return false
	}
	for i := 1; i < len(s); i++ {
		c := s[i]
		if !(c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '_') {
			return false
		}
	}
	return true
}

func decimal(s string) bool {
	if s == "" {
		return false
	}
	for i := range s {
		if s[i] < '0' || s[i] > '9' {
			return false
		}
	}
	return true
}

func parse(data []byte) ([]instruction, error) {
	if len(data) > maxInput {
		return nil, fmt.Errorf("vm: input too large")
	}
	lines := physicalLines(data)
	for i, line := range lines {
		for j := range line {
			if line[j] >= 128 {
				return nil, sourceError(i+1, j+1, "expected ASCII")
			}
		}
	}
	var program []instruction
	var labels []label
	records := 0
	for i, line := range lines {
		trimmed := strings.TrimLeft(line, " \t")
		if trimmed == "" || trimmed[0] == '#' {
			continue
		}
		if records == 10000 {
			return nil, sourceError(i+1, 1, "too many records")
		}
		records++
		if tab := strings.IndexByte(line, '\t'); tab >= 0 {
			return nil, sourceError(i+1, tab+1, "tab is not allowed")
		}
		for j := range line {
			if line[j] == '#' && (j == 0 || line[j-1] == ' ') {
				line = line[:j]
				break
			}
		}
		var tokens []string
		var cols []int
		for j := 0; j < len(line); {
			if line[j] == ' ' {
				j++
				continue
			}
			start := j
			for j < len(line) && line[j] != ' ' {
				j++
			}
			tokens = append(tokens, line[start:j])
			cols = append(cols, start+1)
		}
		first := tokens[0]
		fail := func(message string) ([]instruction, error) { return nil, sourceError(i+1, cols[0], message) }
		if strings.HasSuffix(first, ":") {
			if len(tokens) != 1 {
				return fail("wrong operand count")
			}
			name := strings.TrimSuffix(first, ":")
			if !validLabel(name) {
				return fail("invalid label")
			}
			labels = append(labels, label{name, len(program), i + 1, cols[0]})
			continue
		}
		operands := 0
		switch first {
		case "PUSH", "JMP", "JZ":
			operands = 1
		case "DUP", "DROP", "SWAP", "ADD", "SUB", "MUL", "DIV", "MOD", "OUT", "HALT":
		default:
			return fail("unknown instruction")
		}
		if len(tokens) != operands+1 {
			return fail("wrong operand count")
		}
		inst := instruction{op: first, line: i + 1, col: cols[0]}
		if operands == 1 {
			operand := tokens[1]
			inst.operandCol = cols[1]
			if first == "PUSH" {
				digits := operand
				if strings.HasPrefix(digits, "+") || strings.HasPrefix(digits, "-") {
					digits = digits[1:]
				}
				if !decimal(digits) {
					return nil, sourceError(i+1, cols[1], "invalid integer")
				}
				value, err := strconv.ParseInt(operand, 10, 64)
				if err != nil || value < -maxInteger || value > maxInteger {
					return nil, sourceError(i+1, cols[1], "integer out of range")
				}
				inst.value = value
			} else {
				if !validLabel(operand) {
					return nil, sourceError(i+1, cols[1], "invalid label")
				}
				inst.target = operand
			}
		}
		program = append(program, inst)
	}
	destinations := make(map[string]int)
	for _, l := range labels {
		if _, exists := destinations[l.name]; exists {
			return nil, sourceError(l.line, l.col, "duplicate label")
		}
		destinations[l.name] = l.dest
	}
	for i := range program {
		inst := &program[i]
		if inst.op == "JMP" || inst.op == "JZ" {
			dest, exists := destinations[inst.target]
			if !exists {
				return nil, sourceError(inst.line, inst.operandCol, "unknown label")
			}
			inst.dest = dest
		}
	}
	return program, nil
}

// Run parses and validates the complete source before executing it. Output is
// returned only on success, so a runtime failure cannot leak partial output.
func Run(data []byte, steps, stackLimit int) (string, error) {
	program, err := parse(data)
	if err != nil {
		return "", err
	}
	var stack []int64
	var output strings.Builder
	for pc, executed := 0, 0; pc < len(program); executed++ {
		inst := program[pc]
		fail := func(message string) (string, error) { return "", sourceError(inst.line, inst.col, message) }
		if executed == steps {
			return fail("step limit exceeded")
		}
		required := 0
		switch inst.op {
		case "DUP", "DROP", "OUT", "JZ":
			required = 1
		case "SWAP", "ADD", "SUB", "MUL", "DIV", "MOD":
			required = 2
		}
		if len(stack) < required {
			return fail("stack underflow")
		}
		if (inst.op == "PUSH" || inst.op == "DUP") && len(stack) == stackLimit {
			return fail("stack overflow")
		}
		n := len(stack)
		pc++
		switch inst.op {
		case "PUSH":
			stack = append(stack, inst.value)
		case "DUP":
			stack = append(stack, stack[n-1])
		case "DROP":
			stack = stack[:n-1]
		case "SWAP":
			stack[n-1], stack[n-2] = stack[n-2], stack[n-1]
		case "OUT":
			fmt.Fprintf(&output, "%d\n", stack[n-1])
			stack = stack[:n-1]
		case "JMP":
			pc = inst.dest
		case "JZ":
			if stack[n-1] == 0 {
				pc = inst.dest
			}
			stack = stack[:n-1]
		case "HALT":
			return output.String(), nil
		default:
			left, right := stack[n-2], stack[n-1]
			var result int64
			switch inst.op {
			case "ADD":
				result = left + right
			case "SUB":
				result = left - right
			case "MUL":
				result = left * right
			case "DIV", "MOD":
				if right == 0 {
					return fail("division by zero")
				}
				if inst.op == "DIV" {
					result = left / right
				} else {
					result = left % right
				}
			}
			if result < -maxInteger || result > maxInteger {
				return fail("integer overflow")
			}
			stack = append(stack[:n-2], result)
		}
	}
	return output.String(), nil
}
