package main

import (
	"fmt"
	"strconv"
	"strings"
)

const usage = `Usage: kogen-vm [--steps N] [--stack N] [FILE|-]
Run a bounded integer stack program.
Options:
  --steps N    Maximum instructions executed (default 10000).
  --stack N    Maximum stack depth (default 256).
  --help       Show this help.
`

func execute(args []string) (string, int, error) {
	if len(args) == 1 && args[0] == "--help" {
		return usage, 0, nil
	}
	steps, stack := 10000, 256
	seen := make(map[string]bool)
	path, hasPath := "", false
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch arg {
		case "--steps", "--stack":
			if seen[arg] {
				return "", 2, fmt.Errorf("vm: duplicate option '%s'", arg)
			}
			seen[arg] = true
			if i+1 == len(args) {
				return "", 2, fmt.Errorf("vm: option '%s' requires a value", arg)
			}
			i++
			raw := args[i]
			if !decimal(raw) {
				return "", 2, fmt.Errorf("vm: invalid value for '%s': '%s'", arg, raw)
			}
			value, err := strconv.ParseUint(raw, 10, 64)
			maximum := uint64(100000)
			if arg == "--stack" {
				maximum = 4096
			}
			if err != nil || value < 1 || value > maximum {
				return "", 2, fmt.Errorf("vm: value out of range for '%s': '%s'", arg, raw)
			}
			if arg == "--steps" {
				steps = int(value)
			} else {
				stack = int(value)
			}
		default:
			if strings.HasPrefix(arg, "-") && arg != "-" {
				return "", 2, fmt.Errorf("vm: unknown option '%s'", arg)
			}
			if hasPath {
				return "", 2, fmt.Errorf("vm: expected at most one input path")
			}
			path, hasPath = arg, true
		}
	}
	data, err := Load(path, hasPath, "vm")
	if err != nil {
		return "", 1, err
	}
	output, err := Run(data, steps, stack)
	if err != nil {
		return "", 1, err
	}
	return output, 0, nil
}
