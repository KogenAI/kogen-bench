package main

import (
	"bytes"
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestCLI(t *testing.T) {
	dir := t.TempDir()
	binary := filepath.Join(dir, "kogen")
	build := exec.Command("go", "build", "-o", binary, ".")
	if output, err := build.CombinedOutput(); err != nil {
		t.Fatalf("build: %v\n%s", err, output)
	}
	inputFile := filepath.Join(dir, "source")
	if err := os.WriteFile(inputFile, []byte("PUSH 42\nOUT\n"), 0600); err != nil {
		t.Fatal(err)
	}
	type cliCase struct {
		name                      string
		args                      []string
		input, output, diagnostic string
		status                    int
	}
	tests := []cliCase{
		{"help", []string{"--help"}, "invalid", usage, "", 0},
		{"stdin", nil, "PUSH 3\nOUT", "3\n", "", 0},
		{"dash", []string{"-"}, "PUSH 4\nOUT", "4\n", "", 0},
		{"file", []string{inputFile}, "invalid", "42\n", "", 0},
		{"missing file", []string{filepath.Join(dir, "missing")}, "", "", "vm: cannot read input", 1},
		{"second path", []string{inputFile, "-"}, "", "", "vm: expected at most one input path", 2},
		{"help not sole", []string{"--help", "-"}, "", "", "vm: unknown option '--help'", 2},
		{"unknown", []string{"--bogus"}, "", "", "vm: unknown option '--bogus'", 2},
		{"first error", []string{"--steps", "bad", "--bogus"}, "", "", "vm: invalid value for '--steps': 'bad'", 2},
		{"limits", []string{"--stack", "1", "--steps", "1"}, "PUSH 1\nOUT", "", "vm:2:1: step limit exceeded", 1},
		{"rollback", nil, "PUSH 1\nOUT\nDROP", "", "vm:3:1: stack underflow", 1},
	}
	// The countdown executes exactly 10000 instructions, excluding labels.
	countdown := "PUSH 2000\nloop:\nPUSH 1\nSUB\nDUP\nJZ end\nJMP loop\nend:\n"
	fullStack := strings.Repeat("PUSH 1\n", 256)
	tests = append(tests,
		cliCase{"default steps at limit", nil, countdown, "", "", 0},
		cliCase{"default steps exceeded", nil, countdown + "HALT", "", "vm:9:1: step limit exceeded", 1},
		cliCase{"raised step limit", []string{"--steps", "10001"}, countdown + "HALT", "", "", 0},
		cliCase{"default stack at limit", nil, fullStack + "OUT", "1\n", "", 0},
		cliCase{"default stack exceeded", nil, fullStack + "DUP\nOUT", "", "vm:257:1: stack overflow", 1},
		cliCase{"raised stack limit", []string{"--stack", "257"}, fullStack + "DUP\nOUT", "1\n", "", 0},
	)
	for _, option := range []string{"--steps", "--stack"} {
		maximum := "100000"
		above := "100001"
		if option == "--stack" {
			maximum = "4096"
			above = "4097"
		}
		tests = append(tests,
			cliCase{"missing " + option, []string{option}, "", "", "vm: option '" + option + "' requires a value", 2},
			cliCase{"duplicate " + option, []string{option, "1", option}, "", "", "vm: duplicate option '" + option + "'", 2},
		)
		for _, value := range []string{"", "-1", "+1", "1a", "--help", "\xff"} {
			tests = append(tests, cliCase{"invalid " + option + value, []string{option, value}, "", "", "vm: invalid value for '" + option + "': '" + value + "'", 2})
		}
		for _, value := range []string{"0", above, strings.Repeat("9", 100)} {
			tests = append(tests, cliCase{"range " + option + value, []string{option, value}, "", "", "vm: value out of range for '" + option + "': '" + value + "'", 2})
		}
		for _, value := range []string{"1", "0001", maximum} {
			tests = append(tests, cliCase{"valid " + option + value, []string{option, value}, "HALT", "", "", 0})
		}
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cmd := exec.Command(binary, tt.args...)
			cmd.Stdin = strings.NewReader(tt.input)
			var stdout, stderr bytes.Buffer
			cmd.Stdout, cmd.Stderr = &stdout, &stderr
			err := cmd.Run()
			status := 0
			if err != nil {
				if exit, ok := err.(*exec.ExitError); ok {
					status = exit.ExitCode()
				} else {
					t.Fatal(err)
				}
			}
			wantErr := tt.diagnostic
			if wantErr != "" {
				wantErr += "\n"
			}
			if status != tt.status || stdout.String() != tt.output || stderr.String() != wantErr {
				t.Fatalf("got status=%d stdout=%q stderr=%q; want %d %q %q", status, stdout.String(), stderr.String(), tt.status, tt.output, wantErr)
			}
		})
	}
	// Keep stdin open: help and argument errors must exit without waiting for EOF.
	for _, args := range [][]string{{"--help"}, {"--steps"}} {
		reader, writer, err := os.Pipe()
		if err != nil {
			t.Fatal(err)
		}
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		cmd := exec.CommandContext(ctx, binary, args...)
		cmd.Stdin = reader
		err = cmd.Run()
		reader.Close()
		writer.Close()
		if ctx.Err() != nil {
			t.Fatal("command waited for input")
		}
		if args[0] == "--help" && err != nil {
			t.Fatal(err)
		}
	}
}
