package main

import (
	"fmt"
	"strings"
	"testing"
)

func TestRun(t *testing.T) {
	tests := []struct{ name, source, output, diagnostic string }{
		{"empty", "", "", ""},
		{"arithmetic", "PUSH +0008\nPUSH 3\nSUB\nPUSH 2\nMUL\nPUSH 1\nADD\nOUT", "11\n", ""},
		{"stack operations", "PUSH 1\nDUP\nPUSH 2\nSWAP\nOUT\nDROP\nOUT", "1\n1\n", ""},
		{"negative division", "PUSH -7\nPUSH 3\nDIV\nOUT", "-2\n", ""},
		{"negative remainder", "PUSH -7\nPUSH 3\nMOD\nOUT", "-1\n", ""},
		{"negative divisor", "PUSH 7\nPUSH -3\nMOD\nOUT", "1\n", ""},
		{"zero branch pops", "PUSH 9\nPUSH 0\nJZ end\nOUT\nend:\nOUT", "9\n", ""},
		{"nonzero branch pops", "PUSH 9\nPUSH 1\nJZ end\nPUSH 4\nOUT\nend:\nOUT", "4\n9\n", ""},
		{"jump past end", "JMP end\nOUT\nend:", "", ""},
		{"halt", "HALT\nOUT", "", ""},
		{"halt validates", "HALT\nBOGUS", "", "2:1: unknown instruction"},
		{"halt resolves", "HALT\nJMP absent", "", "2:5: unknown label"},
		{"comments", "\t # ignored\n PUSH 4 # note\r\nOUT\r", "4\n", ""},
		{"attached comment", "PUSH 4#note", "", "1:6: invalid integer"},
		{"tab", "  PUSH\t1", "", "1:7: tab is not allowed"},
		{"ascii precedence", "BOGUS\n a\xff", "", "2:3: expected ASCII"},
		{"syntax before duplicate", "x:\nx:\nPUSH", "", "3:1: wrong operand count"},
		{"duplicate before unresolved", "JMP absent\nx:\n x:", "", "3:2: duplicate label"},
		{"unknown target", "  JMP absent", "", "1:7: unknown label"},
		{"invalid label", "A:", "", "1:1: invalid label"},
		{"label arity", "ok: extra", "", "1:1: wrong operand count"},
		{"bad target", "JZ Bad", "", "1:4: invalid label"},
		{"case sensitive", "push 1", "", "1:1: unknown instruction"},
		{"extra operand", "OUT 1", "", "1:1: wrong operand count"},
		{"bare sign", "PUSH +", "", "1:6: invalid integer"},
		{"range high", "PUSH 1000000000", "", "1:6: integer out of range"},
		{"range low", "PUSH -1000000000", "", "1:6: integer out of range"},
		{"range endpoints", "PUSH -999999999\nOUT\nPUSH 999999999\nOUT", "-999999999\n999999999\n", ""},
		{"rollback", "PUSH 7\nOUT\nDROP", "", "3:1: stack underflow"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			out, err := Run([]byte(tt.source), 10000, 256)
			wantErr := ""
			if tt.diagnostic != "" {
				wantErr = "vm:" + tt.diagnostic
			}
			gotErr := ""
			if err != nil {
				gotErr = err.Error()
			}
			if out != tt.output || gotErr != wantErr {
				t.Fatalf("got (%q, %q), want (%q, %q)", out, gotErr, tt.output, wantErr)
			}
		})
	}
}

func TestRuntimeFailures(t *testing.T) {
	for _, op := range []string{"DUP", "DROP", "SWAP", "ADD", "SUB", "MUL", "DIV", "MOD", "OUT", "JZ"} {
		source := op
		if op == "JZ" {
			source += " end\nend:"
		}
		_, err := Run([]byte(source), 10, 1)
		if err == nil || err.Error() != "vm:1:1: stack underflow" {
			t.Fatalf("%s: %v", op, err)
		}
	}
	// Binary instructions need both operands; in particular a lone zero must
	// report underflow rather than division by zero for DIV and MOD.
	for _, op := range []string{"SWAP", "ADD", "SUB", "MUL", "DIV", "MOD"} {
		out, err := Run([]byte("PUSH 0\n  "+op), 10, 1)
		if out != "" || err == nil || err.Error() != "vm:2:3: stack underflow" {
			t.Fatalf("%s with one operand: output=%q error=%v", op, out, err)
		}
	}
	for _, op := range []string{"DIV", "MOD"} {
		_, err := Run([]byte("PUSH 1\nPUSH 0\n"+op), 10, 2)
		if err == nil || err.Error() != "vm:3:1: division by zero" {
			t.Fatal(err)
		}
	}
	for _, source := range []string{"PUSH 999999999\nPUSH 1\nADD", "PUSH -999999999\nPUSH 1\nSUB", "PUSH 999999999\nDUP\nMUL"} {
		_, err := Run([]byte(source), 10, 2)
		if err == nil || err.Error() != "vm:3:1: integer overflow" {
			t.Fatal(err)
		}
	}
}

func TestLimits(t *testing.T) {
	for _, tt := range []struct {
		source       string
		steps, stack int
		diagnostic   string
	}{
		{"PUSH 1\nOUT", 1, 1, "vm:2:1: step limit exceeded"},
		{"PUSH 1\nHALT", 2, 1, ""},
		{"PUSH 1", 1, 1, ""},
		{"PUSH 1\nDUP", 2, 1, "vm:2:1: stack overflow"},
		{"PUSH 1\nPUSH 2", 2, 1, "vm:2:1: stack overflow"},
		{"loop:\nJMP loop", 2, 1, "vm:2:1: step limit exceeded"},
	} {
		_, err := Run([]byte(tt.source), tt.steps, tt.stack)
		got := ""
		if err != nil {
			got = err.Error()
		}
		if got != tt.diagnostic {
			t.Fatalf("%q: %q", tt.source, got)
		}
	}
	for _, size := range []int{maxInput - 1, maxInput, maxInput + 1} {
		_, err := Run([]byte("#"+strings.Repeat("a", size-1)), 1, 1)
		if (err != nil) != (size > maxInput) {
			t.Fatalf("size %d: %v", size, err)
		}
	}
	for _, count := range []int{9999, 10000, 10001} {
		source := strings.Repeat("HALT\n", count)
		if count == 10001 {
			source = strings.Repeat("HALT\n", 10000) + "BOGUS\t"
		}
		_, err := Run([]byte(source), 1, 1)
		if count <= 10000 && err != nil {
			t.Fatal(err)
		}
		if count > 10000 && (err == nil || err.Error() != fmt.Sprintf("vm:%d:1: too many records", count)) {
			t.Fatal(err)
		}
	}
}
