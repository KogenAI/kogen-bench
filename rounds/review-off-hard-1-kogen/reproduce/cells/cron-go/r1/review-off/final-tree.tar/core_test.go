package main

import (
	"fmt"
	"strings"
	"testing"
	"time"
)

func TestArguments(t *testing.T) {
	cases := []struct {
		args []string
		want string
	}{
		{[]string{"--after"}, "option '--after' requires a value"},
		{[]string{"--count"}, "option '--count' requires a value"},
		{[]string{"--format"}, "option '--format' requires a value"},
		{[]string{"--after", "2000-01-01T00:00", "--after"}, "duplicate option '--after'"},
		{[]string{"--count", "1", "--count"}, "duplicate option '--count'"},
		{[]string{"--format", "text", "--format"}, "duplicate option '--format'"},
		{[]string{"--count", "--help"}, "invalid value for '--count': '--help'"},
		{[]string{"--count", "+1"}, "invalid value for '--count': '+1'"},
		{[]string{"--count", ""}, "invalid value for '--count': ''"},
		{[]string{"--count", "0"}, "value out of range for '--count': '0'"},
		{[]string{"--count", "21"}, "value out of range for '--count': '21'"},
		{[]string{"--count", strings.Repeat("9", 100)}, "value out of range for '--count': '" + strings.Repeat("9", 100) + "'"},
		{[]string{"--format", "JSON"}, "invalid value for '--format': 'JSON'"},
		{[]string{"--help", "-"}, "unknown option '--help'"},
		{[]string{"a", "b"}, "expected at most one input path"},
		{[]string{"--bad", "--count"}, "unknown option '--bad'"},
	}
	for _, tc := range cases {
		t.Run(strings.Join(tc.args, " "), func(t *testing.T) {
			out, code, err := execute(tc.args)
			if out != "" || code != 2 || err == nil || err.Error() != "cron: "+tc.want {
				t.Fatalf("got %q %d %v", out, code, err)
			}
		})
	}
	for _, stamp := range []string{"1970-01-01T00:00", "2190-12-31T23:59", "2000-02-29T23:59"} {
		if _, err := arguments([]string{"--after", stamp}); err != nil {
			t.Fatal(err)
		}
	}
	for _, stamp := range []string{"1969-12-31T23:59", "2191-01-01T00:00", "2100-02-29T00:00", "2000-13-01T00:00", "2000-01-00T00:00", "2000-01-01T24:00", "2000-01-01T00:60", "2000-1-01T00:00", "2000-01-01T0:00", "2000-01-01T00:00Z"} {
		if _, err := arguments([]string{"--after", stamp}); err == nil {
			t.Fatalf("accepted %s", stamp)
		}
	}
	for _, count := range []string{"1", "2", "19", "20", "00001"} {
		if _, err := arguments([]string{"--count", count}); err != nil {
			t.Fatal(err)
		}
	}
	o, err := arguments([]string{"-"})
	if err != nil || !o.hasPath || o.path != "-" || o.count != 3 || o.format != "text" || o.after.Format(stampLayout) != "2000-01-01T00:00" {
		t.Fatalf("defaults: %+v %v", o, err)
	}
}

func TestFields(t *testing.T) {
	cases := []struct {
		text     string
		min, max int
		want     string
	}{
		{"1,3-7/2", 0, 59, "1,3,5,7"},
		{"57/2", 0, 59, "57,59"},
		{"*/12", 1, 12, "1"},
		{"1-3", 1, 31, "1,2,3"},
		{"0007,7", 0, 7, "7"},
		{"*/8", 0, 7, "0"},
	}
	for _, tc := range cases {
		f, ok := parseField(tc.text, tc.min, tc.max)
		var selected []string
		for i, v := range f.values {
			if v {
				selected = append(selected, fmt.Sprint(i))
			}
		}
		if !ok || strings.Join(selected, ",") != tc.want {
			t.Fatalf("%s: %v %v", tc.text, ok, selected)
		}
	}
	for j := 0; j < 5; j++ {
		min, max := minima[j], maxima[j]
		for _, text := range []string{fmt.Sprint(min), fmt.Sprint(max), "*", fmt.Sprintf("*/%d", max-min+1)} {
			if _, ok := parseField(text, min, max); !ok {
				t.Fatalf("rejected %s in field %d", text, j)
			}
		}
		for _, text := range []string{"", ",1", "1,", "1,,2", "-1", "+1", "1/0", "1//2", "1/", "*/-1", "1-0", "1-2-3", "**", "1.0", fmt.Sprint(max + 1), fmt.Sprintf("*/%d", max-min+2)} {
			if _, ok := parseField(text, min, max); ok {
				t.Fatalf("accepted %q in field %d", text, j)
			}
		}
	}
	if f, _ := parseField("*/1", 1, 31); f.wild {
		t.Fatal("stepped wildcard marked unrestricted")
	}
}

func TestParsingOrderAndColumns(t *testing.T) {
	cases := []struct{ input, want string }{
		{"bad\n# \xff", "cron:2:3: expected ASCII"},
		{"# \r\n  \xff", "cron:2:3: expected ASCII"},
		{"bad\tx", "cron:1:4: tab is not allowed"},
		{"  bad * *", "cron:1:3: wrong field count"},
		{"  BAD * * * * *", "cron:1:3: invalid name"},
		{"  job  *  24 * * *", "cron:1:11: invalid hour field"},
		{"job * * 0 * *", "cron:1:9: invalid day-of-month field"},
		{"job * * * 13 *", "cron:1:11: invalid month field"},
		{"job * * * * 8", "cron:1:13: invalid day-of-week field"},
		{"job * * * * *\n job * * * * *", "cron:2:2: duplicate name"},
		{"job * * * * *\njob * * * * *\nbad", "cron:3:1: wrong field count"},
		{strings.Repeat("#", 1048577), "cron: input too large"},
		{strings.Repeat("x * * * * *\n", 1000) + "\tbad", "cron:1001:1: too many schedules"},
	}
	for _, tc := range cases {
		_, err := parse([]byte(tc.input))
		if err == nil || err.Error() != tc.want {
			t.Fatalf("input %.40q: got %v, want %s", tc.input, err, tc.want)
		}
	}
	for _, input := range []string{"", " \t\r\n\t# comment\t\r", strings.Repeat("#", 1048576)} {
		r, err := parse([]byte(input))
		if err != nil || len(r) != 0 {
			t.Fatalf("ignored input: %v %v", r, err)
		}
	}
	for _, name := range []string{"a", "a0123456789_-abc"} {
		if _, err := parse([]byte(name + " * * * * *\r\n")); err != nil {
			t.Fatal(err)
		}
	}
	for _, name := range []string{"A", "0a", strings.Repeat("a", 17), "a.b"} {
		if _, err := parse([]byte(name + " * * * * *")); err == nil {
			t.Fatalf("accepted name %s", name)
		}
	}
}

func TestSearchAndRendering(t *testing.T) {
	cases := []struct {
		input, after, format string
		count                int
		want                 string
	}{
		{"every * * * * *", "1970-01-01T00:00", "text", 2, "every\t1\t2\n"},
		{"picks 1,3-7/2 * * * *", "1970-01-01T00:00", "text", 3, "picks\t1\t3\t5\n"},
		{"day 0 0 1 * 0", "1970-01-01T00:00", "text", 3, "day\t4320\t14400\t24480\n"},
		{"sun 0 0 * * 7", "1970-01-01T00:00", "text", 1, "sun\t4320\n"},
		{"dom 0 0 2 * *", "1970-01-01T00:00", "text", 1, "dom\t1440\n"},
		{"restricted 0 0 */1 * 0", "1970-01-01T00:00", "text", 1, "restricted\t1440\n"},
		{"one 1 0 1 1 *\ntwo 2 0 1 1 *", "1970-01-01T00:00", "json", 1, "{\"schedules\":[{\"name\":\"one\",\"runs\":[1]},{\"name\":\"two\",\"runs\":[2]}]}\n"},
		{"", "1970-01-01T00:00", "json", 1, "{\"schedules\":[]}\n"},
		{"", "1970-01-01T00:00", "text", 1, ""},
		{"last * * * * *", "2190-12-31T23:59", "text", 1, fmt.Sprintf("last\t%d\n", mustTime("2191-01-01T00:00").Unix()/60)},
	}
	for _, tc := range cases {
		o := options{after: mustTime(tc.after), count: tc.count, format: tc.format}
		out, err := render([]byte(tc.input), o)
		if err != nil || out != tc.want {
			t.Fatalf("%s: got %q %v want %q", tc.input, out, err, tc.want)
		}
	}
	for _, input := range []string{"first * * * * *\nleap 0 0 29 2 *", "first * * * * *\nnever 0 0 31 2 *"} {
		out, err := render([]byte(input), options{after: mustTime("2096-03-01T00:00"), count: 20, format: "text"})
		if out != "" || err == nil || err.Error() != "cron:2:1: not enough occurrences in search horizon" {
			t.Fatalf("got %q %v", out, err)
		}
	}
	// Century leap rules and the inclusive endpoint of the search interval.
	for _, start := range []string{"1999-03-01T00:00", "2099-03-01T00:00"} {
		records, _ := parse([]byte("leap 0 0 29 2 *"))
		runs, err := occurrences(records[0], mustTime(start), 1)
		year := 2000
		if strings.HasPrefix(start, "2099") {
			year = 2104
		}
		want := time.Date(year, 2, 29, 0, 0, 0, 0, time.UTC).Unix() / 60
		if err != nil || len(runs) != 1 || runs[0] != want {
			t.Fatalf("leap: %v %v", runs, err)
		}
	}
	start := mustTime("2000-01-01T00:00")
	records, _ := parse([]byte("daily 0 0 * * *"))
	runs, err := occurrences(records[0], start, 8*366)
	if err != nil || runs[len(runs)-1] != start.Unix()/60+horizon {
		t.Fatalf("endpoint missing: %v", err)
	}
	if _, err = occurrences(records[0], start, 8*366+1); err == nil {
		t.Fatal("searched beyond horizon")
	}
}

func mustTime(s string) time.Time {
	t, err := time.Parse(stampLayout, s)
	if err != nil {
		panic(err)
	}
	return t
}
