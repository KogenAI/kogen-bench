package main

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"
)

const help = `Usage: kogen-cron [--after YYYY-MM-DDTHH:MM] [--count N] [--format text|json] [FILE|-]
Find upcoming UTC minutes for named cron expressions.
Options:
  --after VALUE    Exclusive UTC starting minute (default 2000-01-01T00:00).
  --count N        Occurrences per expression (default 3; range 1..20).
  --format FORMAT  Output text (default) or json.
  --help           Show this help.
`
const stampLayout = "2006-01-02T15:04"
const horizon = 8 * 366 * 24 * 60

type options struct {
	after        time.Time
	count        int
	format, path string
	hasPath      bool
}

// decimal returns a bounded integer, saturating above max without overflow.
func decimal(s string, max int) (int, bool) {
	if s == "" {
		return 0, false
	}
	n := 0
	for i := range s {
		if s[i] < '0' || s[i] > '9' {
			return 0, false
		}
		if n <= max {
			n = n*10 + int(s[i]-'0')
		}
	}
	return n, true
}

func arguments(args []string) (options, error) {
	after, _ := time.Parse(stampLayout, "2000-01-01T00:00")
	o := options{after: after, count: 3, format: "text"}
	seen := map[string]bool{}
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch arg {
		case "--after", "--count", "--format":
			if seen[arg] {
				return o, fmt.Errorf("cron: duplicate option '%s'", arg)
			}
			seen[arg] = true
			if i+1 == len(args) {
				return o, fmt.Errorf("cron: option '%s' requires a value", arg)
			}
			i++
			value := args[i]
			invalid := false
			switch arg {
			case "--after":
				t, err := time.Parse(stampLayout, value)
				invalid = err != nil || t.Format(stampLayout) != value || t.Year() < 1970 || t.Year() > 2190
				o.after = t
			case "--count":
				n, ok := decimal(value, 20)
				invalid = !ok
				if ok && (n < 1 || n > 20) {
					return o, fmt.Errorf("cron: value out of range for '--count': '%s'", value)
				}
				o.count = n
			case "--format":
				invalid = value != "text" && value != "json"
				o.format = value
			}
			if invalid {
				return o, fmt.Errorf("cron: invalid value for '%s': '%s'", arg, value)
			}
		default:
			if strings.HasPrefix(arg, "-") && arg != "-" {
				return o, fmt.Errorf("cron: unknown option '%s'", arg)
			}
			if o.hasPath {
				return o, fmt.Errorf("cron: expected at most one input path")
			}
			o.path, o.hasPath = arg, true
		}
	}
	return o, nil
}

type field struct {
	values [60]bool
	wild   bool
}
type record struct {
	name         string
	line, column int
	fields       [5]field
}

var namePattern = regexp.MustCompile(`^[a-z][a-z0-9_-]{0,15}$`)
var fieldLabels = [5]string{"minute", "hour", "day-of-month", "month", "day-of-week"}
var minima = [5]int{0, 0, 1, 1, 0}
var maxima = [5]int{59, 23, 31, 12, 7}

func parseField(text string, min, max int) (field, bool) {
	f := field{wild: text == "*"}
	for _, term := range strings.Split(text, ",") {
		parts := strings.Split(term, "/")
		if len(parts) > 2 {
			return f, false
		}
		step := 1
		if len(parts) == 2 {
			var ok bool
			step, ok = decimal(parts[1], max-min+1)
			if !ok || step < 1 || step > max-min+1 {
				return f, false
			}
		}
		lo, hi := min, max
		if parts[0] != "*" {
			ends := strings.Split(parts[0], "-")
			if len(ends) > 2 {
				return f, false
			}
			var ok bool
			lo, ok = decimal(ends[0], max)
			if !ok || lo < min || lo > max {
				return f, false
			}
			hi = lo
			if len(ends) == 2 {
				hi, ok = decimal(ends[1], max)
				if !ok || hi < lo || hi > max {
					return f, false
				}
			} else if len(parts) == 2 {
				hi = max
			}
		}
		for n := lo; n <= hi; n += step {
			f.values[n] = true
		}
	}
	return f, true
}
func sourceError(line, col int, message string) error {
	return fmt.Errorf("cron:%d:%d: %s", line, col, message)
}

func parse(data []byte) ([]record, error) {
	if len(data) > 1048576 {
		return nil, fmt.Errorf("cron: input too large")
	}
	lines := physicalLines(data)
	for i, line := range lines {
		for j := 0; j < len(line); j++ {
			if line[j] > 127 {
				return nil, sourceError(i+1, j+1, "expected ASCII")
			}
		}
	}
	records := []record{}
	for i, line := range lines {
		trimmed := strings.Trim(line, " \t")
		if trimmed == "" || trimmed[0] == '#' {
			continue
		}
		if len(records) == 1000 {
			return nil, sourceError(i+1, 1, "too many schedules")
		}
		if j := strings.IndexByte(line, '\t'); j >= 0 {
			return nil, sourceError(i+1, j+1, "tab is not allowed")
		}
		var tokens []string
		start := len(line) - len(strings.TrimLeft(line, " "))
		// Only ASCII spaces separate tokens; other ASCII bytes remain token content.
		tokens = strings.Split(strings.Trim(line, " "), " ")
		compact := tokens[:0]
		for _, token := range tokens {
			if token != "" {
				compact = append(compact, token)
			}
		}
		tokens = compact
		if len(tokens) != 6 {
			return nil, sourceError(i+1, start+1, "wrong field count")
		}
		r := record{name: tokens[0], line: i + 1, column: start + 1}
		if !namePattern.MatchString(r.name) {
			return nil, sourceError(i+1, start+1, "invalid name")
		}
		pos := start + len(tokens[0])
		for j := 0; j < 5; j++ {
			for pos < len(line) && line[pos] == ' ' {
				pos++
			}
			f, ok := parseField(tokens[j+1], minima[j], maxima[j])
			if !ok {
				return nil, sourceError(i+1, pos+1, "invalid "+fieldLabels[j]+" field")
			}
			r.fields[j] = f
			pos += len(tokens[j+1])
		}
		// Seven is an additional spelling of Sunday.
		r.fields[4].values[0] = r.fields[4].values[0] || r.fields[4].values[7]
		records = append(records, r)
	}
	seen := map[string]bool{}
	for _, r := range records {
		if seen[r.name] {
			return nil, sourceError(r.line, r.column, "duplicate name")
		}
		seen[r.name] = true
	}
	return records, nil
}

func occurrences(r record, after time.Time, count int) ([]int64, error) {
	start := after.Unix() / 60
	end := start + horizon
	runs := []int64{}
	f := r.fields
	day := time.Date(after.Year(), after.Month(), after.Day(), 0, 0, 0, 0, time.UTC)
	for day.Unix()/60 <= end {
		dom, dow := f[2].values[day.Day()], f[4].values[int(day.Weekday())]
		matches := dom || dow
		if f[2].wild {
			matches = dow
		}
		if f[4].wild {
			matches = dom
		}
		if f[2].wild && f[4].wild {
			matches = true
		}
		if f[3].values[int(day.Month())] && matches {
			base := day.Unix() / 60
			for h := 0; h < 24; h++ {
				if f[1].values[h] {
					for m := 0; m < 60; m++ {
						if f[0].values[m] {
							candidate := base + int64(h*60+m)
							if candidate > start && candidate <= end {
								runs = append(runs, candidate)
								if len(runs) == count {
									return runs, nil
								}
							}
						}
					}
				}
			}
		}
		day = day.AddDate(0, 0, 1)
	}
	return nil, sourceError(r.line, 1, "not enough occurrences in search horizon")
}

func render(data []byte, o options) (string, error) {
	records, err := parse(data)
	if err != nil {
		return "", err
	}
	var b strings.Builder
	if o.format == "json" {
		b.WriteString(`{"schedules":[`)
	}
	for i, r := range records {
		runs, err := occurrences(r, o.after, o.count)
		if err != nil {
			return "", err
		}
		if o.format == "json" {
			if i > 0 {
				b.WriteByte(',')
			}
			b.WriteString(`{"name":"` + r.name + `","runs":[`)
		} else {
			b.WriteString(r.name)
		}
		for j, n := range runs {
			if o.format == "text" {
				b.WriteByte('\t')
			} else if j > 0 {
				b.WriteByte(',')
			}
			b.WriteString(strconv.FormatInt(n, 10))
		}
		if o.format == "json" {
			b.WriteString(`]}`)
		} else {
			b.WriteByte('\n')
		}
	}
	if o.format == "json" {
		b.WriteString("]}\n")
	}
	return b.String(), nil
}

func execute(args []string) (string, int, error) {
	if len(args) == 1 && args[0] == "--help" {
		return help, 0, nil
	}
	o, err := arguments(args)
	if err != nil {
		return "", 2, err
	}
	data, err := Load(o.path, o.hasPath, "cron")
	if err != nil {
		return "", 1, err
	}
	output, err := render(data, o)
	if err != nil {
		return "", 1, err
	}
	return output, 0, nil
}
