package main

import (
	"bytes"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

// The test subprocess enters the same main as the built executable.
func TestCLIProcess(t *testing.T) {
	if os.Getenv("CRON_TEST_PROCESS") == "1" {
		for i, arg := range os.Args {
			if arg == "--" {
				os.Args = append([]string{os.Args[0]}, os.Args[i+1:]...)
				main()
				return
			}
		}
	}
}

func TestCLIStreamsAndFiles(t *testing.T) {
	dir := t.TempDir()
	input := filepath.Join(dir, "schedules")
	if err := os.WriteFile(input, []byte("job * * * * *\n"), 0600); err != nil {
		t.Fatal(err)
	}
	cases := []struct {
		args               []string
		input, out, stderr string
		status             int
	}{
		{[]string{"--help"}, "invalid", help, "", 0},
		{[]string{"--after", "1970-01-01T00:00", "--count", "1"}, "job * * * * *\n", "job\t1\n", "", 0},
		{[]string{"--after", "1970-01-01T00:00", "--count", "1", "-"}, "job * * * * *\n", "job\t1\n", "", 0},
		{[]string{"--after", "1970-01-01T00:00", "--count", "1", input}, "bad stdin", "job\t1\n", "", 0},
		{[]string{filepath.Join(dir, "missing")}, "", "", "cron: cannot read input\n", 1},
		{[]string{"--count", "0", filepath.Join(dir, "missing")}, "", "", "cron: value out of range for '--count': '0'\n", 2},
		{nil, "job 60 * * * *\n", "", "cron:1:5: invalid minute field\n", 1},
		{[]string{"--format", "json"}, "", "{\"schedules\":[]}\n", "", 0},
	}
	for _, tc := range cases {
		cmd := exec.Command(os.Args[0], append([]string{"-test.run=^TestCLIProcess$", "--"}, tc.args...)...)
		cmd.Env = append(os.Environ(), "CRON_TEST_PROCESS=1")
		cmd.Stdin = bytes.NewBufferString(tc.input)
		var out, stderr bytes.Buffer
		cmd.Stdout = &out
		cmd.Stderr = &stderr
		err := cmd.Run()
		status := 0
		if err != nil {
			if exit, ok := err.(*exec.ExitError); ok {
				status = exit.ExitCode()
			} else {
				t.Fatal(err)
			}
		}
		if status != tc.status || out.String() != tc.out || stderr.String() != tc.stderr {
			t.Fatalf("%v: got status %d stdout %q stderr %q", tc.args, status, out.String(), stderr.String())
		}
	}
}
