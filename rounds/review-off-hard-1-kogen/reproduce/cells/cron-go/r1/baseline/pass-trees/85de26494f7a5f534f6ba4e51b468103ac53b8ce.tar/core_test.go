package main

import (
	"fmt"
	"reflect"
	"strings"
	"testing"
	"time"
)

func TestArguments(t *testing.T) {
	cases := []struct {
		args    []string
		message string
	}{
		{[]string{"--after"}, "option '--after' requires a value"},
		{[]string{"--count"}, "option '--count' requires a value"},
		{[]string{"--format"}, "option '--format' requires a value"},
		{[]string{"--after", "2000-01-01T00:00", "--after"}, "duplicate option '--after'"},
		{[]string{"--count", "1", "--count"}, "duplicate option '--count'"},
		{[]string{"--format", "text", "--format"}, "duplicate option '--format'"},
		{[]string{"--count", "--help"}, "invalid value for '--count': '--help'"},
		{[]string{"--help", "--count"}, "unknown option '--help'"},
		{[]string{"x", "y"}, "expected at most one input path"},
	}
	for _, v := range []string{"", "-1", "1x", "١"} {
		cases = append(cases, struct {
			args    []string
			message string
		}{[]string{"--count", v}, "invalid value for '--count': '" + v + "'"})
	}
	for _, v := range []string{"0", "21", strings.Repeat("9", 100)} {
		cases = append(cases, struct {
			args    []string
			message string
		}{[]string{"--count", v}, "value out of range for '--count': '" + v + "'"})
	}
	for _, v := range []string{"1969-12-31T23:59", "2191-01-01T00:00", "2000-1-01T00:00", "2001-02-29T00:00", "2100-02-29T00:00", "2000-00-01T00:00", "2000-13-01T00:00", "2000-01-00T00:00", "2000-04-31T00:00", "2000-01-01T24:00", "2000-01-01T00:60", "2000-01-01T00:00Z"} {
		cases = append(cases, struct {
			args    []string
			message string
		}{[]string{"--after", v}, "invalid value for '--after': '" + v + "'"})
	}
	cases = append(cases, struct {
		args    []string
		message string
	}{[]string{"--format", "JSON"}, "invalid value for '--format': 'JSON'"})
	for _, tc := range cases {
		t.Run(strings.Join(tc.args, " "), func(t *testing.T) {
			_, code, err := execute(tc.args)
			if code != 2 || err == nil || err.Error() != "cron: "+tc.message {
				t.Fatalf("got %d %v", code, err)
			}
		})
	}
	for _, v := range []string{"1970-01-01T00:00", "1970-01-01T00:01", "2190-12-31T23:58", "2190-12-31T23:59", "2000-02-29T23:59"} {
		if _, err := arguments([]string{"--after", v}); err != nil {
			t.Fatal(err)
		}
	}
	for _, v := range []string{"1", "2", "19", "20", "00001"} {
		if _, err := arguments([]string{"--count", v}); err != nil {
			t.Fatal(err)
		}
	}
}

func TestFields(t *testing.T) {
	for _, tc := range []struct {
		s      string
		lo, hi int
		want   []int
	}{
		{"1,3-7/2", 0, 59, []int{1, 3, 5, 7}}, {"55/2", 0, 59, []int{55, 57, 59}},
		{"*/12", 1, 12, []int{1}}, {"000/060", 0, 59, []int{0}}, {"7", 0, 7, []int{7}},
		{"0,0,00-00/01", 0, 59, []int{0}},
	} {
		f, ok := parseField(tc.s, tc.lo, tc.hi)
		got := []int{}
		for n, v := range f.values {
			if v {
				got = append(got, n)
			}
		}
		if !ok || !reflect.DeepEqual(got, tc.want) {
			t.Errorf("%s got %v, %v", tc.s, got, ok)
		}
	}
	for _, bounds := range [][2]int{{0, 59}, {0, 23}, {1, 31}, {1, 12}, {0, 7}} {
		lo, hi := bounds[0], bounds[1]
		valid := []string{"*", "*/1", fmt.Sprint(lo), fmt.Sprint(hi), fmt.Sprintf("%d-%d", lo, hi), fmt.Sprintf("*/%d", hi-lo+1)}
		invalid := []string{"", ",1", "1,", "1,,2", "+1", "-1", "1.0", "1/0", "1/-1", "1/", "1//2", "**", "3-1", "1-2-3", "1/*", fmt.Sprint(hi + 1), fmt.Sprintf("*/%d", hi-lo+2), strings.Repeat("9", 100)}
		if lo > 0 {
			invalid = append(invalid, "0")
		}
		for _, s := range valid {
			if _, ok := parseField(s, lo, hi); !ok {
				t.Errorf("valid %s [%d,%d]", s, lo, hi)
			}
		}
		for _, s := range invalid {
			if _, ok := parseField(s, lo, hi); ok {
				t.Errorf("invalid %s [%d,%d]", s, lo, hi)
			}
		}
	}
}

func TestSourceDiagnostics(t *testing.T) {
	cases := []struct{ input, want string }{
		{"bad\n#\xff", "cron:2:2: expected ASCII"},
		{"a\r\n \xff\r", "cron:2:2: expected ASCII"},
		{"job\t60 * * * *", "cron:1:4: tab is not allowed"},
		{"  job * *", "cron:1:3: wrong field count"},
		{" Bad * * * * *", "cron:1:2: invalid name"},
		{"abcdefghijklmnopq * * * * *", "cron:1:1: invalid name"},
		{"job * 24 * * *", "cron:1:7: invalid hour field"},
		{"job * * 0 * *", "cron:1:9: invalid day-of-month field"},
		{"job * * * 13 *", "cron:1:11: invalid month field"},
		{"job * * * * 8", "cron:1:13: invalid day-of-week field"},
		{"job * * * * *\n job * * * * *", "cron:2:2: duplicate name"},
		{"job * * * * *\njob * * * * *\nx 60 * * * *", "cron:3:3: invalid minute field"},
	}
	for _, tc := range cases {
		_, err := parse([]byte(tc.input))
		if err == nil || err.Error() != tc.want {
			t.Errorf("%q: %v, want %s", tc.input, err, tc.want)
		}
	}
	if _, err := parse([]byte(strings.Repeat(" ", inputLimit))); err != nil {
		t.Fatal(err)
	}
	if _, err := parse([]byte(strings.Repeat(" ", inputLimit) + "\xff")); err == nil || err.Error() != "cron: input too large" {
		t.Fatal(err)
	}
	var b strings.Builder
	for i := 0; i < 1000; i++ {
		fmt.Fprintf(&b, "n%d * * * * *\n", i)
	}
	b.WriteString("\t# comment\n \t\n")
	if records, err := parse([]byte(b.String())); err != nil || len(records) != 1000 {
		t.Fatalf("%d %v", len(records), err)
	}
	b.WriteString("\tinvalid")
	if _, err := parse([]byte(b.String())); err == nil || err.Error() != "cron:1003:1: too many schedules" {
		t.Fatal(err)
	}
}

func TestEvaluate(t *testing.T) {
	cases := []struct {
		input, after string
		count        int
		format, want string
	}{
		{"every * * * * *", "1970-01-01T00:00", 2, "text", "every\t1\t2\n"},
		{"day 0 0 1 * 0", "1970-01-01T00:00", 3, "text", "day\t4320\t14400\t24480\n"},
		{"sun 0 0 * * 7", "1970-01-01T00:00", 1, "text", "sun\t4320\n"},
		{"dom 0 0 2 * *", "1970-01-01T00:00", 1, "text", "dom\t1440\n"},
		{"restricted 0 0 */1 * 0", "1970-01-01T00:00", 1, "text", "restricted\t1440\n"},
		{"#\tcomment\r\n \t\r\n", "1970-01-01T00:00", 1, "text", ""},
		{"", "1970-01-01T00:00", 1, "json", "{\"schedules\":[]}\n"},
		{"one 1 0 1 1 *\ntwo 2 0 1 1 *", "1970-01-01T00:00", 1, "json", "{\"schedules\":[{\"name\":\"one\",\"runs\":[1]},{\"name\":\"two\",\"runs\":[2]}]}\n"},
	}
	for _, tc := range cases {
		after, _ := time.Parse("2006-01-02T15:04", tc.after)
		got, err := evaluate([]byte(tc.input), options{after: after, count: tc.count, format: tc.format})
		if err != nil || got != tc.want {
			t.Errorf("%s: %q %v want %q", tc.input, got, err, tc.want)
		}
	}
}

func TestSearchCalendarAndHorizon(t *testing.T) {
	for _, tc := range []struct{ after, input, want string }{
		{"2000-02-28T23:59", "leap 0 0 29 2 *", "2000-02-29T00:00"},
		{"2096-03-01T00:00", "leap 0 0 29 2 *", "2104-02-29T00:00"},
		{"2190-12-31T23:59", "next * * * * *", "2191-01-01T00:00"},
	} {
		o, _ := arguments([]string{"--after", tc.after, "--count", "1"})
		want, _ := time.Parse("2006-01-02T15:04", tc.want)
		got, err := evaluate([]byte(tc.input), o)
		if err != nil || got != strings.Fields(tc.input)[0]+"\t"+fmt.Sprint(want.Unix()/60)+"\n" {
			t.Fatalf("%q %v", got, err)
		}
	}
	after := time.Date(2000, 1, 1, 0, 0, 0, 0, time.UTC)
	end := after.Add(time.Duration(horizon) * time.Minute)
	// A yearly expression yields its ninth occurrence exactly on the horizon.
	input := fmt.Sprintf("edge %d %d %d %d *", end.Minute(), end.Hour(), end.Day(), end.Month())
	records, err := parse([]byte(input))
	if err != nil {
		t.Fatal(err)
	}
	runs, err := occurrences(records[0], after, 10)
	if err == nil || runs != nil {
		t.Fatalf("want insufficient occurrences: %v %v", runs, err)
	}
	runs, err = occurrences(records[0], after, 9)
	if err != nil || runs[8] != end.Unix()/60 {
		t.Fatalf("inclusive horizon: %v %v", runs, err)
	}
	runs, err = occurrences(records[0], after.Add(-time.Minute), 9)
	if err == nil || runs != nil {
		t.Fatalf("beyond horizon: %v %v", runs, err)
	}
	o, _ := arguments([]string{"--after", "2096-03-01T00:00", "--count", "20"})
	got, err := evaluate([]byte("first * * * * *\nleap 0 0 29 2 *"), o)
	if got != "" || err == nil || err.Error() != "cron:2:1: not enough occurrences in search horizon" {
		t.Fatalf("%q %v", got, err)
	}
}

// These schedules cannot match, so searching before completing validation
// would mask the required syntax or duplicate-name diagnostic.
func TestEvaluationErrorPrecedence(t *testing.T) {
	o, err := arguments([]string{"--count", "1"})
	if err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct{ input, want string }{
		{"impossible 0 0 31 2 *\nbroken 60 * * * *", "cron:2:8: invalid minute field"},
		{"impossible 0 0 31 2 *\n impossible * * * * *", "cron:2:2: duplicate name"},
		{"first 0 0 31 2 *\nsecond 0 0 31 4 *", "cron:1:1: not enough occurrences in search horizon"},
		{"ready * * * * *\nimpossible 0 0 31 2 *", "cron:2:1: not enough occurrences in search horizon"},
	} {
		for _, format := range []string{"text", "json"} {
			o.format = format
			got, err := evaluate([]byte(tc.input), o)
			if got != "" || err == nil || err.Error() != tc.want {
				t.Errorf("%s %q: got %q, %v; want empty output and %s", format, tc.input, got, err, tc.want)
			}
		}
	}
}

func TestOrderedDistinctRuns(t *testing.T) {
	o, err := arguments([]string{"--after", "1970-01-01T00:58", "--count", "4", "--format", "json"})
	if err != nil {
		t.Fatal(err)
	}
	// Overlapping terms must not duplicate minutes; the hour rollover must
	// retain chronological ordering, independently for each input record.
	got, err := evaluate([]byte("z 0,0-1,59 * * * *\na 0/30 * * * *"), o)
	want := "{\"schedules\":[{\"name\":\"z\",\"runs\":[59,60,61,119]},{\"name\":\"a\",\"runs\":[60,90,120,150]}]}\n"
	if err != nil || got != want {
		t.Fatalf("got %q, %v; want %q", got, err, want)
	}
}
