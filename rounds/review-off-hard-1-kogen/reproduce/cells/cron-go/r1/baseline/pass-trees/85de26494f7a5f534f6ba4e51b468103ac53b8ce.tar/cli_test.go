package main

import (
	"bytes"
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// Re-enter the real CLI boundary in an isolated process, including its streams
// and exit status, without compiling another binary for each test.
func TestCLIProcess(t *testing.T) {
	if os.Getenv("CRON_TEST_PROCESS") == "1" {
		os.Args = append([]string{"kogen-cron"}, os.Args[3:]...)
		main()
		return
	}
	dir := t.TempDir()
	path := filepath.Join(dir, "schedules")
	if err := os.WriteFile(path, []byte("job * * * * *\r\n"), 0600); err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct {
		name     string
		args     []string
		input    string
		code     int
		out, err string
	}{
		{"help", []string{"--help"}, "invalid\xff", 0, usage, ""},
		{"defaults", nil, "job * * * * *", 0, "job\t15778081\t15778082\t15778083\n", ""},
		{"stdin", []string{"--after", "1970-01-01T00:00", "--count", "1"}, "job * * * * *", 0, "job\t1\n", ""},
		{"dash", []string{"--after", "1970-01-01T00:00", "--count", "1", "-"}, "job * * * * *", 0, "job\t1\n", ""},
		{"file", []string{"--after", "1970-01-01T00:00", "--count", "1", path}, "invalid", 0, "job\t1\n", ""},
		{"missing file", []string{filepath.Join(dir, "missing")}, "", 1, "", "cron: cannot read input\n"},
		{"read failure", []string{dir}, "", 1, "", "cron: cannot read input\n"},
		{"argument before read", []string{filepath.Join(dir, "missing"), "--count"}, "", 2, "", "cron: option '--count' requires a value\n"},
		{"size before ascii", nil, strings.Repeat(" ", inputLimit) + "\xff", 1, "", "cron: input too large\n"},
		{"ascii before syntax", nil, "bad\n\xff", 1, "", "cron:2:1: expected ASCII\n"},
		{"empty json", []string{"--format", "json"}, "", 0, "{\"schedules\":[]}\n", ""},
	} {
		t.Run(tc.name, func(t *testing.T) {
			args := append([]string{"-test.run=^TestCLIProcess$", "--"}, tc.args...)
			cmd := exec.Command(os.Args[0], args...)
			cmd.Env = append(os.Environ(), "CRON_TEST_PROCESS=1")
			cmd.Stdin = strings.NewReader(tc.input)
			var out, stderr bytes.Buffer
			cmd.Stdout = &out
			cmd.Stderr = &stderr
			err := cmd.Run()
			code := 0
			if err != nil {
				if exit, ok := err.(*exec.ExitError); ok {
					code = exit.ExitCode()
				} else {
					t.Fatal(err)
				}
			}
			if code != tc.code || out.String() != tc.out || stderr.String() != tc.err {
				t.Fatalf("got status %d stdout %q stderr %q; want %d %q %q", code, out.String(), stderr.String(), tc.code, tc.out, tc.err)
			}
		})
	}
}

func TestCLIDoesNotReadInput(t *testing.T) {
	for _, tc := range []struct {
		name     string
		args     []string
		code     int
		out, err string
	}{
		{"help", []string{"--help"}, 0, usage, ""},
		{"argument error", []string{"--count"}, 2, "", "cron: option '--count' requires a value\n"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			// Keep stdin open without sending any bytes. A CLI that reads input
			// before handling these arguments will block until the timeout.
			reader, writer, err := os.Pipe()
			if err != nil {
				t.Fatal(err)
			}
			defer reader.Close()
			defer writer.Close()
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			defer cancel()
			args := append([]string{"-test.run=^TestCLIProcess$", "--"}, tc.args...)
			cmd := exec.CommandContext(ctx, os.Args[0], args...)
			cmd.Env = append(os.Environ(), "CRON_TEST_PROCESS=1")
			cmd.Stdin = reader
			var out, stderr bytes.Buffer
			cmd.Stdout, cmd.Stderr = &out, &stderr
			err = cmd.Run()
			if ctx.Err() != nil {
				t.Fatalf("CLI blocked with unread stdin: %v", ctx.Err())
			}
			code := 0
			if err != nil {
				if exit, ok := err.(*exec.ExitError); ok {
					code = exit.ExitCode()
				} else {
					t.Fatal(err)
				}
			}
			if code != tc.code || out.String() != tc.out || stderr.String() != tc.err {
				t.Fatalf("got status %d stdout %q stderr %q; want %d %q %q", code, out.String(), stderr.String(), tc.code, tc.out, tc.err)
			}
		})
	}
}
