package main

import (
	"fmt"
	"strconv"
	"strings"
	"time"
)

const usage = "Usage: kogen-cron [--after YYYY-MM-DDTHH:MM] [--count N] [--format text|json] [FILE|-]\nFind upcoming UTC minutes for named cron expressions.\nOptions:\n  --after VALUE    Exclusive UTC starting minute (default 2000-01-01T00:00).\n  --count N        Occurrences per expression (default 3; range 1..20).\n  --format FORMAT  Output text (default) or json.\n  --help           Show this help.\n"
const inputLimit = 1048576
const horizon = 8 * 366 * 24 * 60

type options struct {
	after        time.Time
	count        int
	format, path string
	hasPath      bool
}

// decimal validates all digits even after the bounded accumulator overflows.
func decimal(s string, max int) (int, bool) {
	if s == "" {
		return 0, false
	}
	n := 0
	for i := 0; i < len(s); i++ {
		if s[i] < '0' || s[i] > '9' {
			return 0, false
		}
		if n <= max {
			n = n*10 + int(s[i]-'0')
		}
	}
	return n, true
}

func arguments(args []string) (options, error) {
	o := options{after: time.Date(2000, 1, 1, 0, 0, 0, 0, time.UTC), count: 3, format: "text"}
	seen := map[string]bool{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--after", "--count", "--format":
			if seen[a] {
				return o, fmt.Errorf("cron: duplicate option '%s'", a)
			}
			seen[a] = true
			if i+1 == len(args) {
				return o, fmt.Errorf("cron: option '%s' requires a value", a)
			}
			i++
			v := args[i]
			invalid := false
			switch a {
			case "--after":
				t, e := time.Parse("2006-01-02T15:04", v)
				invalid = e != nil || t.Format("2006-01-02T15:04") != v || t.Year() < 1970 || t.Year() > 2190
				o.after = t
			case "--count":
				n, ok := decimal(v, 20)
				invalid = !ok
				if ok && (n < 1 || n > 20) {
					return o, fmt.Errorf("cron: value out of range for '--count': '%s'", v)
				}
				o.count = n
			case "--format":
				invalid = v != "text" && v != "json"
				o.format = v
			}
			if invalid {
				return o, fmt.Errorf("cron: invalid value for '%s': '%s'", a, v)
			}
		default:
			if strings.HasPrefix(a, "-") && a != "-" {
				return o, fmt.Errorf("cron: unknown option '%s'", a)
			}
			if o.hasPath {
				return o, fmt.Errorf("cron: expected at most one input path")
			}
			o.hasPath = true
			o.path = a
		}
	}
	return o, nil
}

type field struct {
	values [60]bool
	wild   bool
}

func parseField(s string, lo, hi int) (field, bool) {
	f := field{wild: s == "*"}
	for _, term := range strings.Split(s, ",") {
		parts := strings.Split(term, "/")
		if len(parts) > 2 {
			return f, false
		}
		step := 1
		if len(parts) == 2 {
			n, ok := decimal(parts[1], hi-lo+1)
			if !ok || n < 1 || n > hi-lo+1 {
				return f, false
			}
			step = n
		}
		base := parts[0]
		a, b := lo, hi
		if base != "*" {
			ends := strings.Split(base, "-")
			if len(ends) > 2 {
				return f, false
			}
			n, ok := decimal(ends[0], hi)
			if !ok || n < lo || n > hi {
				return f, false
			}
			a = n
			if len(ends) == 2 {
				n, ok = decimal(ends[1], hi)
				if !ok || n < a || n > hi {
					return f, false
				}
				b = n
			} else if len(parts) == 1 {
				b = a
			}
		}
		for n := a; n <= b; n += step {
			f.values[n] = true
		}
	}
	return f, true
}

type schedule struct {
	name      string
	line, col int
	fields    [5]field
}

func sourceError(line, col int, message string) error {
	return fmt.Errorf("cron:%d:%d: %s", line, col, message)
}
func validName(s string) bool {
	if len(s) < 1 || len(s) > 16 || s[0] < 'a' || s[0] > 'z' {
		return false
	}
	for i := 1; i < len(s); i++ {
		c := s[i]
		if !(c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '_' || c == '-') {
			return false
		}
	}
	return true
}

func parse(data []byte) ([]schedule, error) {
	if len(data) > inputLimit {
		return nil, fmt.Errorf("cron: input too large")
	}
	lines := physicalLines(data)
	for i, line := range lines {
		for col := 0; col < len(line); col++ {
			if line[col] > 127 {
				return nil, sourceError(i+1, col+1, "expected ASCII")
			}
		}
	}
	records := []schedule{}
	labels := [5]string{"minute", "hour", "day-of-month", "month", "day-of-week"}
	lows := [5]int{0, 0, 1, 1, 0}
	highs := [5]int{59, 23, 31, 12, 7}
	for i, line := range lines {
		trimmed := strings.TrimLeft(line, " \t")
		if trimmed == "" || trimmed[0] == '#' {
			continue
		}
		if len(records) == 1000 {
			return nil, sourceError(i+1, 1, "too many schedules")
		}
		if col := strings.IndexByte(line, '\t'); col >= 0 {
			return nil, sourceError(i+1, col+1, "tab is not allowed")
		}
		tokens := []string{}
		cols := []int{}
		for j := 0; j < len(line); {
			if line[j] == ' ' {
				j++
				continue
			}
			start := j
			for j < len(line) && line[j] != ' ' {
				j++
			}
			tokens = append(tokens, line[start:j])
			cols = append(cols, start+1)
		}
		if len(tokens) != 6 {
			return nil, sourceError(i+1, cols[0], "wrong field count")
		}
		if !validName(tokens[0]) {
			return nil, sourceError(i+1, cols[0], "invalid name")
		}
		r := schedule{name: tokens[0], line: i + 1, col: cols[0]}
		for k := 0; k < 5; k++ {
			f, ok := parseField(tokens[k+1], lows[k], highs[k])
			if !ok {
				return nil, sourceError(i+1, cols[k+1], "invalid "+labels[k]+" field")
			}
			r.fields[k] = f
		}
		records = append(records, r)
	}
	seen := map[string]bool{}
	for _, r := range records {
		if seen[r.name] {
			return nil, sourceError(r.line, r.col, "duplicate name")
		}
		seen[r.name] = true
	}
	return records, nil
}

func occurrences(r schedule, after time.Time, count int) ([]int64, error) {
	start := after.Unix() / 60
	end := start + horizon
	day := time.Date(after.Year(), after.Month(), after.Day(), 0, 0, 0, 0, time.UTC)
	runs := []int64{}
	f := r.fields
	for day.Unix()/60 <= end {
		dom := f[2].values[day.Day()]
		dow := f[4].values[int(day.Weekday())] || day.Weekday() == time.Sunday && f[4].values[7]
		match := dom || dow
		if f[2].wild {
			match = dow
		}
		if f[4].wild {
			match = dom
		}
		if f[2].wild && f[4].wild {
			match = true
		}
		if f[3].values[int(day.Month())] && match {
			base := day.Unix() / 60
			for h := 0; h < 24; h++ {
				if !f[1].values[h] {
					continue
				}
				for m := 0; m < 60; m++ {
					if !f[0].values[m] {
						continue
					}
					v := base + int64(h*60+m)
					if v > start && v <= end {
						runs = append(runs, v)
						if len(runs) == count {
							return runs, nil
						}
					}
				}
			}
		}
		day = day.AddDate(0, 0, 1)
	}
	return nil, sourceError(r.line, 1, "not enough occurrences in search horizon")
}

func evaluate(data []byte, o options) (string, error) {
	records, err := parse(data)
	if err != nil {
		return "", err
	}
	var out strings.Builder
	if o.format == "json" {
		out.WriteString("{\"schedules\":[")
	}
	for i, r := range records {
		runs, err := occurrences(r, o.after, o.count)
		if err != nil {
			return "", err
		}
		if o.format == "json" {
			if i > 0 {
				out.WriteByte(',')
			}
			out.WriteString("{\"name\":\"" + r.name + "\",\"runs\":[")
		} else {
			out.WriteString(r.name)
		}
		for j, v := range runs {
			if o.format == "text" {
				out.WriteByte('\t')
			} else if j > 0 {
				out.WriteByte(',')
			}
			out.WriteString(strconv.FormatInt(v, 10))
		}
		if o.format == "json" {
			out.WriteString("]}")
		} else {
			out.WriteByte('\n')
		}
	}
	if o.format == "json" {
		out.WriteString("]}\n")
	}
	return out.String(), nil
}

func execute(args []string) (string, int, error) {
	if len(args) == 1 && args[0] == "--help" {
		return usage, 0, nil
	}
	o, err := arguments(args)
	if err != nil {
		return "", 2, err
	}
	data, err := Load(o.path, o.hasPath, "cron")
	if err != nil {
		return "", 1, err
	}
	out, err := evaluate(data, o)
	if err != nil {
		return "", 1, err
	}
	return out, 0, nil
}
