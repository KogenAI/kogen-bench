defmodule Kogen.CronTest do
  use ExUnit.Case, async: true
  alias Kogen.{Core, Cron, Error}

  defp error(fun, message, code \\ 1) do
    exception = assert_raise Error, message, fun
    assert exception.code == code
  end

  test "argument defaults and boundaries" do
    assert Core.options([]) == %{after: 15_778_080, count: 3, format: "text", path: nil}
    assert Core.options(["--after", "1970-01-01T00:00", "--count", "0001"]).after == 0
    assert Core.options(["--after", "2190-12-31T23:59", "--count", "20"]).count == 20

    for value <- [
          "1969-12-31T23:59",
          "2191-01-01T00:00",
          "2100-02-29T00:00",
          "2000-01-01T24:00",
          "2000-01-01T00:60",
          "2000-1-01T00:00"
        ] do
      error(
        fn -> Core.options(["--after", value]) end,
        "cron: invalid value for '--after': '#{value}'",
        2
      )
    end

    assert Core.options(["--after", "2000-02-29T00:00"]).after > 0

    for option <- ["--after", "--count", "--format"] do
      valid = %{"--after" => "2000-01-01T00:00", "--count" => "1", "--format" => "json"}[option]
      error(fn -> Core.options([option]) end, "cron: option '#{option}' requires a value", 2)

      error(
        fn -> Core.options([option, valid, option]) end,
        "cron: duplicate option '#{option}'",
        2
      )

      error(
        fn -> Core.options([option, "--help"]) end,
        "cron: invalid value for '#{option}': '--help'",
        2
      )
    end

    for value <- ["0", "21", String.duplicate("9", 100)] do
      error(
        fn -> Core.options(["--count", value]) end,
        "cron: value out of range for '--count': '#{value}'",
        2
      )
    end

    for value <- ["", "+1", "1x", "١"] do
      error(
        fn -> Core.options(["--count", value]) end,
        "cron: invalid value for '--count': '#{value}'",
        2
      )
    end

    error(
      fn -> Core.options(["--format", "JSON"]) end,
      "cron: invalid value for '--format': 'JSON'",
      2
    )

    error(fn -> Core.options(["--help", "x"]) end, "cron: unknown option '--help'", 2)
    error(fn -> Core.options(["a", "b"]) end, "cron: expected at most one input path", 2)
    assert Core.options(["-"]).path == "-"
  end

  test "field forms, bounds, and restricted wildcard" do
    assert Cron.field("1,3-7/2,01", 0, 59) == MapSet.new([1, 3, 5, 7])
    assert Cron.field("55/2", 0, 59) == MapSet.new([55, 57, 59])
    assert Cron.field("*/60", 0, 59) == MapSet.new([0])

    for {low, high} <- [{0, 59}, {0, 23}, {1, 31}, {1, 12}, {0, 7}] do
      assert Cron.field("*", low, high) == MapSet.new(low..high)
      assert Cron.field("#{low}-#{high}", low, high) == MapSet.new(low..high)
      assert Cron.field("*/#{high - low + 1}", low, high) == MapSet.new([low])

      for text <- [
            "#{low - 1}",
            "#{high + 1}",
            "#{high}-#{low}",
            "*/0",
            "*/#{high - low + 2}",
            "1,",
            ",1",
            "",
            "1//2",
            "1/",
            "+1",
            "1-2-3"
          ] do
        assert Cron.field(text, low, high) == :invalid
      end
    end

    [record] = Cron.parse("job 0 0 */1 * 1")
    assert Cron.runs(record, 0, 2) == [1440, 2880]
  end

  test "whole input checks precede syntax and normalization keeps byte columns" do
    error(fn -> Cron.parse("bad\n#\r\n  " <> <<255>>) end, "cron:3:3: expected ASCII")

    error(
      fn -> Cron.parse(String.duplicate(" ", 1_048_576) <> <<255>>) end,
      "cron: input too large"
    )

    assert Cron.parse(String.duplicate(" ", 1_048_576)) == []
    assert Cron.parse(" \t# comment\t\r\n\t \r\n") == []
    assert length(Cron.parse("job * * * * *\r")) == 1
    error(fn -> Cron.parse("  bad\t") end, "cron:1:6: tab is not allowed")
    error(fn -> Cron.parse("  bad") end, "cron:1:3: wrong field count")
    error(fn -> Cron.parse("  Bad * * * * *") end, "cron:1:3: invalid name")

    for name <- ["a", "a" <> String.duplicate("0", 15), "a_-0"] do
      assert [%{name: ^name}] = Cron.parse("#{name} * * * * *")
    end

    error(
      fn -> Cron.parse("#{String.duplicate("a", 17)} * * * * *") end,
      "cron:1:1: invalid name"
    )

    error(
      fn -> Cron.parse("job * * * * *\njob * * * * *\nbad") end,
      "cron:3:1: wrong field count"
    )

    error(fn -> Cron.parse("job * * * * *\n  job * * * * *") end, "cron:2:3: duplicate name")
  end

  test "record limit is applied before tabs or grammar" do
    source = Enum.map_join(1..1000, "\n", &"n#{&1} * * * * *")
    assert length(Cron.parse(source)) == 1000
    error(fn -> Cron.parse(source <> "\n# ignored\n\tbad") end, "cron:1002:1: too many schedules")
  end

  test "UTC search is exclusive, sorted, aliases Sunday, and uses day OR" do
    [every, picks, day, sunday] =
      Cron.parse("every * * * * *\npicks 7,1,3-7/2 * * * *\nday 0 0 1 * 0\nsunday 0 0 * * 7")

    assert Cron.runs(every, 0, 2) == [1, 2]
    assert Cron.runs(picks, 0, 3) == [1, 3, 5]
    assert Cron.runs(day, 0, 3) == [4320, 14400, 24480]
    assert Cron.runs(sunday, 0, 1) == [4320]
    [leap] = Cron.parse("leap 0 0 29 2 *")
    after_minute = Core.options(["--after", "2096-03-01T00:00"]).after

    error(
      fn -> Cron.runs(leap, after_minute, 20) end,
      "cron:1:1: not enough occurrences in search horizon"
    )

    first = hd(Cron.runs(leap, after_minute, 1))
    assert NaiveDateTime.add(~N[1970-01-01 00:00:00], first * 60) == ~N[2104-02-29 00:00:00]
  end
end
