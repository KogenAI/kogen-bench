defmodule Kogen.Core do
  @moduledoc "Argument parsing and execution for the UTC cron CLI."
  import Kogen.Input, only: [fail: 2]

  @help """
  Usage: kogen-cron [--after YYYY-MM-DDTHH:MM] [--count N] [--format text|json] [FILE|-]
  Find upcoming UTC minutes for named cron expressions.
  Options:
    --after VALUE    Exclusive UTC starting minute (default 2000-01-01T00:00).
    --count N        Occurrences per expression (default 3; range 1..20).
    --format FORMAT  Output text (default) or json.
    --help           Show this help.
  """

  def execute(["--help"]), do: @help

  def execute(args) do
    options = options(args)
    bytes = Kogen.Input.read(options.path, "cron")
    records = Kogen.Cron.parse(bytes)
    runs = Enum.map(records, &{&1.name, Kogen.Cron.runs(&1, options.after, options.count)})
    render(runs, options.format)
  end

  @doc "Parse CLI arguments without reading input."
  def options(args) do
    scan(args, %{after: 15_778_080, count: 3, format: "text", path: nil}, MapSet.new())
  end

  defp scan([], options, _seen), do: options

  defp scan([option | rest], options, seen) when option in ["--after", "--count", "--format"] do
    if MapSet.member?(seen, option), do: fail("cron: duplicate option '#{option}'", 2)

    case rest do
      [] ->
        fail("cron: option '#{option}' requires a value", 2)

      [value | tail] ->
        key =
          case option do
            "--after" -> :after
            "--count" -> :count
            "--format" -> :format
          end

        parsed = option_value(option, value)
        scan(tail, Map.put(options, key, parsed), MapSet.put(seen, option))
    end
  end

  defp scan([token | rest], options, seen) do
    cond do
      token != "-" and String.starts_with?(token, "-") ->
        fail("cron: unknown option '#{token}'", 2)

      options.path != nil ->
        fail("cron: expected at most one input path", 2)

      true ->
        scan(rest, %{options | path: token}, seen)
    end
  end

  defp invalid(option, value), do: fail("cron: invalid value for '#{option}': '#{value}'", 2)

  defp option_value("--format", value) when value in ["text", "json"], do: value
  defp option_value("--format", value), do: invalid("--format", value)

  defp option_value("--count", value) do
    case Kogen.Cron.number(value, 20) do
      :invalid -> invalid("--count", value)
      n when n < 1 or n > 20 -> fail("cron: value out of range for '--count': '#{value}'", 2)
      n -> n
    end
  end

  defp option_value("--after", value) do
    with true <- Regex.match?(~r/\A[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}\z/, value),
         {:ok, datetime} <- NaiveDateTime.from_iso8601(value <> ":00"),
         true <- datetime.year >= 1970 and datetime.year <= 2190 do
      div(NaiveDateTime.diff(datetime, ~N[1970-01-01 00:00:00]), 60)
    else
      _ -> invalid("--after", value)
    end
  end

  defp render(runs, "text") do
    Enum.map_join(runs, "", fn {name, minutes} ->
      Enum.join([name | minutes], "\t") <> "\n"
    end)
  end

  defp render(runs, "json") do
    items =
      Enum.map_join(runs, ",", fn {name, minutes} ->
        "{\"name\":\"#{name}\",\"runs\":[#{Enum.join(minutes, ",")}]}"
      end)

    "{\"schedules\":[#{items}]}\n"
  end
end
