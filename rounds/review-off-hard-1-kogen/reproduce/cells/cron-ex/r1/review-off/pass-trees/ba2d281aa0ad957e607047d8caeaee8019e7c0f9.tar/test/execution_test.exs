defmodule Kogen.ExecutionTest do
  use ExUnit.Case, async: true
  alias Kogen.{Core, Error}

  setup do
    directory = Path.join(System.tmp_dir!(), "cron-#{System.unique_integer([:positive])}")
    File.mkdir!(directory)
    on_exit(fn -> File.rm_rf!(directory) end)
    {:ok, path: Path.join(directory, "schedules")}
  end

  test "file input is rendered in source order in both formats", %{path: path} do
    File.write!(path, "z 1 * * * *\r\na 2 * * * *\r\n")
    args = ["--after", "1970-01-01T00:00", "--count", "2", path]
    assert Core.execute(args) == "z\t1\t61\na\t2\t62\n"

    assert Core.execute(args ++ ["--format", "json"]) ==
             "{\"schedules\":[{\"name\":\"z\",\"runs\":[1,61]},{\"name\":\"a\",\"runs\":[2,62]}]}\n"

    File.write!(path, "# empty\n")
    assert Core.execute([path]) == ""
    assert Core.execute([path, "--format", "json"]) == "{\"schedules\":[]}\n"
  end

  test "file failures and argument errors precede reading", %{path: path} do
    assert_raise Error, "cron: cannot read input", fn -> Core.execute([path]) end
    assert_raise Error, "cron: unknown option '--bad'", fn -> Core.execute([path, "--bad"]) end
  end

  test "failed later search returns no partial output", %{path: path} do
    File.write!(path, "ok * * * * *\nbad 0 0 31 2 *")

    assert_raise Error, "cron:2:1: not enough occurrences in search horizon", fn ->
      Core.execute([path])
    end
  end
end
