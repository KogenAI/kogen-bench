defmodule Kogen.Cron do
  @moduledoc "ASCII cron parsing and bounded Gregorian UTC occurrence search."
  import Kogen.Input, only: [fail: 1]

  @fields [
    {0, 59, "minute"},
    {0, 23, "hour"},
    {1, 31, "day-of-month"},
    {1, 12, "month"},
    {0, 7, "day-of-week"}
  ]
  @epoch Date.to_gregorian_days(~D[1970-01-01])
  @horizon 8 * 366 * 1440

  @doc "Parse and validate all records, then reject duplicate names."
  def parse(bytes) do
    if byte_size(bytes) > 1_048_576, do: fail("cron: input too large")
    lines = Kogen.Input.physical_lines(bytes) |> Enum.with_index(1)

    Enum.each(lines, fn {line, row} ->
      case Enum.find_index(:binary.bin_to_list(line), &(&1 > 127)) do
        nil -> :ok
        index -> error(row, index + 1, "expected ASCII")
      end
    end)

    {records, _} =
      Enum.reduce(lines, {[], 0}, fn {line, row}, {records, count} ->
        if Regex.match?(~r/\A[ \t]*(?:#|\z)/, line) do
          {records, count}
        else
          if count == 1000, do: error(row, 1, "too many schedules")

          case :binary.match(line, "\t") do
            :nomatch -> :ok
            {index, _} -> error(row, index + 1, "tab is not allowed")
          end

          {[record(line, row) | records], count + 1}
        end
      end)

    records = Enum.reverse(records)

    Enum.reduce(records, MapSet.new(), fn record, names ->
      if MapSet.member?(names, record.name),
        do: error(record.line, record.column, "duplicate name")

      MapSet.put(names, record.name)
    end)

    records
  end

  defp record(line, row) do
    tokens = Regex.scan(~r/[^ ]+/, line, return: :index) |> List.flatten()
    [{start, _} | _] = tokens
    if length(tokens) != 6, do: error(row, start + 1, "wrong field count")
    [{offset, size} | fields] = tokens
    name = binary_part(line, offset, size)

    unless Regex.match?(~r/\A[a-z][a-z0-9_-]{0,15}\z/, name),
      do: error(row, offset + 1, "invalid name")

    parsed =
      Enum.zip(fields, @fields)
      |> Enum.map(fn {{offset, size}, {min, max, label}} ->
        text = binary_part(line, offset, size)

        case field(text, min, max) do
          :invalid -> error(row, offset + 1, "invalid #{label} field")
          values -> {values, text == "*"}
        end
      end)

    %{name: name, line: row, column: offset + 1, fields: parsed}
  end

  @doc "Parse ASCII digits, saturating above the supplied bound."
  def number("", _bound), do: :invalid

  def number(text, bound) do
    text
    |> :binary.bin_to_list()
    |> Enum.reduce_while(0, fn byte, n ->
      if byte in ?0..?9, do: {:cont, min(bound + 1, n * 10 + byte - ?0)}, else: {:halt, :invalid}
    end)
  end

  @doc "Expand a cron field, or return :invalid."
  def field(text, min, max) do
    text
    |> String.split(",")
    |> Enum.reduce_while(MapSet.new(), fn term, values ->
      case term(term, min, max) do
        :invalid -> {:halt, :invalid}
        selected -> {:cont, MapSet.union(values, MapSet.new(selected))}
      end
    end)
  end

  defp term(text, min, max) do
    case String.split(text, "/") do
      [base] ->
        expand(base, nil, min, max)

      [base, step] ->
        n = number(step, max - min + 1)

        if is_integer(n) and n in 1..(max - min + 1),
          do: expand(base, n, min, max),
          else: :invalid

      _ ->
        :invalid
    end
  end

  defp expand(base, step, min, max) do
    bounds =
      case String.split(base, "-") do
        ["*"] ->
          {min, max}

        [value] ->
          n = number(value, max)
          {n, if(step == nil, do: n, else: max)}

        [a, b] ->
          {number(a, max), number(b, max)}

        _ ->
          {:invalid, :invalid}
      end

    {a, b} = bounds

    if is_integer(a) and is_integer(b) and a >= min and b <= max and a <= b do
      Enum.to_list(a..b//(step || 1))
    else
      :invalid
    end
  end

  @doc "Return the earliest count matches strictly after a UTC epoch minute."
  def runs(record, after_minute, count) do
    [minutes, hours, dom, months, dow] = record.fields
    {minute_set, _} = minutes
    {hour_set, _} = hours
    {month_set, _} = months

    times =
      for hour <- Enum.sort(hour_set), minute <- Enum.sort(minute_set), do: hour * 60 + minute

    last = after_minute + @horizon

    result =
      Enum.reduce_while(div(after_minute, 1440)..div(last, 1440), [], fn day, found ->
        date = Date.from_gregorian_days(@epoch + day)

        if MapSet.member?(month_set, date.month) and day_matches?(date, dom, dow) do
          matches =
            Enum.filter(times, fn time ->
              day * 1440 + time > after_minute and day * 1440 + time <= last
            end)

          next = found ++ Enum.map(Enum.take(matches, count - length(found)), &(day * 1440 + &1))
          if length(next) == count, do: {:halt, next}, else: {:cont, next}
        else
          {:cont, found}
        end
      end)

    if length(result) < count,
      do: error(record.line, 1, "not enough occurrences in search horizon")

    result
  end

  defp day_matches?(date, {dom, dom_wild}, {dow, dow_wild}) do
    weekday = rem(Date.day_of_week(date), 7)
    d = MapSet.member?(dom, date.day)
    w = MapSet.member?(dow, weekday) or (weekday == 0 and MapSet.member?(dow, 7))

    cond do
      dom_wild and dow_wild -> true
      dom_wild -> w
      dow_wild -> d
      true -> d or w
    end
  end

  defp error(line, column, message), do: fail("cron:#{line}:#{column}: #{message}")
end
