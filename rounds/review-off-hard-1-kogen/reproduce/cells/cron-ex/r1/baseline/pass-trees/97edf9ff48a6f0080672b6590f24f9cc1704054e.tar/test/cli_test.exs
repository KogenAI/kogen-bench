defmodule Kogen.CLITest do
  use ExUnit.Case

  setup_all do
    {output, status} = System.cmd("make", ["build"], stderr_to_stdout: true)
    assert status == 0, output
    :ok
  end

  defp cli(args, input \\ "") do
    path = Path.join(System.tmp_dir!(), "cron-input-#{System.unique_integer([:positive])}")
    err = path <> ".err"
    File.write!(path, input)

    try do
      {out, status} =
        System.cmd(
          "sh",
          ["-c", "./run \"$@\" < \"$CRON_INPUT\" 2> \"$CRON_ERROR\"", "cron" | args],
          env: [{"CRON_INPUT", path}, {"CRON_ERROR", err}]
        )

      {out, File.read!(err), status}
    after
      File.rm(path)
      File.rm(err)
    end
  end

  test "argument errors are left-to-right, exact and precede reading" do
    cases = [
      {["--after"], "option '--after' requires a value"},
      {["--count"], "option '--count' requires a value"},
      {["--format"], "option '--format' requires a value"},
      {["--count", "1", "--count"], "duplicate option '--count'"},
      {["--after", "1970-01-01T00:00", "--after"], "duplicate option '--after'"},
      {["--format", "text", "--format"], "duplicate option '--format'"},
      {["--count", "--help"], "invalid value for '--count': '--help'"},
      {["--help", "x"], "unknown option '--help'"},
      {["--other"], "unknown option '--other'"},
      {["a", "b"], "expected at most one input path"},
      {["--format", "JSON"], "invalid value for '--format': 'JSON'"}
    ]

    for {args, message} <- cases do
      assert cli(args, <<255>>) == {"", "cron: #{message}\n", 2}
    end

    for value <- ["", "+1", "-1", "1.0", " 1", "١"] do
      assert cli(["--count", value]) == {"", "cron: invalid value for '--count': '#{value}'\n", 2}
    end

    for value <- ["0", "21", "000", String.duplicate("9", 100)] do
      assert cli(["--count", value]) ==
               {"", "cron: value out of range for '--count': '#{value}'\n", 2}
    end

    for value <- [
          "1969-12-31T23:59",
          "2191-01-01T00:00",
          "2001-02-29T00:00",
          "2100-02-29T00:00",
          "2000-00-01T00:00",
          "2000-13-01T00:00",
          "2000-01-00T00:00",
          "2000-04-31T00:00",
          "2000-01-01T24:00",
          "2000-01-01T00:60",
          "2000-1-01T00:00",
          "2000-01-01T00:00Z"
        ] do
      assert cli(["--after", value]) == {"", "cron: invalid value for '--after': '#{value}'\n", 2}
    end
  end

  test "formats, defaults, count boundaries and file input" do
    assert cli([]) == {"", "", 0}
    assert cli(["--format", "json"]) == {"{\"schedules\":[]}\n", "", 0}
    assert cli([], "job * * * * *") == {"job\t15778081\t15778082\t15778083\n", "", 0}

    for count <- ["1", "0002", "19", "20"] do
      n = String.to_integer(count)

      assert cli(["--after", "1970-01-01T00:00", "--count", count, "-"], "job * * * * *") ==
               {"job\t" <> Enum.join(1..n, "\t") <> "\n", "", 0}
    end

    assert cli(
             ["--after", "1970-01-01T00:00", "--count", "1", "--format", "json"],
             "one * * * * *\ntwo * * * * *"
           ) ==
             {"{\"schedules\":[{\"name\":\"one\",\"runs\":[1]},{\"name\":\"two\",\"runs\":[1]}]}\n",
              "", 0}

    path = Path.join(System.tmp_dir!(), "cron-file-#{System.unique_integer([:positive])}")
    File.write!(path, "file * * * * *")

    try do
      assert cli(["--after", "1970-01-01T00:00", "--count", "1", path], "invalid") ==
               {"file\t1\n", "", 0}
    after
      File.rm!(path)
    end

    assert cli([path]) == {"", "cron: cannot read input\n", 1}
  end

  test "stdin preserves bytes and normalizes line endings before diagnostics" do
    assert cli([], "bad\r\n  " <> <<255>>) == {"", "cron:2:3: expected ASCII\n", 1}

    assert cli(["--after", "1970-01-01T00:00", "--count", "1"], "job * * * * *\r\n") ==
             {"job\t1\n", "", 0}
  end

  test "search failures discard earlier results" do
    assert cli([], "good * * * * *\nbad 0 0 31 2 *") ==
             {"", "cron:2:1: not enough occurrences in search horizon\n", 1}
  end
end
