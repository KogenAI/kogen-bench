defmodule Kogen.Cron do
  @moduledoc "ASCII cron records and bounded UTC occurrence search."
  import Kogen.Input, only: [fail: 1]

  @fields [
    {0, 59, "minute"},
    {0, 23, "hour"},
    {1, 31, "day-of-month"},
    {1, 12, "month"},
    {0, 7, "day-of-week"}
  ]
  @horizon 8 * 366 * 24 * 60
  @epoch ~D[1970-01-01]

  def parse(bytes) do
    if byte_size(bytes) > 1_048_576, do: fail("cron: input too large")
    lines = Kogen.Input.physical_lines(bytes)

    Enum.with_index(lines, 1)
    |> Enum.each(fn {line, row} -> ascii(line, row, 1) end)

    {records, _} =
      Enum.with_index(lines, 1)
      |> Enum.reduce({[], 0}, fn {line, row}, {records, count} ->
        if Regex.match?(~r/\A[ \t]*(?:#|\z)/, line) do
          {records, count}
        else
          if count == 1000, do: source(row, 1, "too many schedules")

          case :binary.match(line, "\t") do
            {col, _} -> source(row, col + 1, "tab is not allowed")
            :nomatch -> :ok
          end

          tokens =
            Regex.scan(~r/[^ ]+/, line, return: :index)
            |> Enum.map(fn [{pos, len}] -> {binary_part(line, pos, len), pos + 1} end)

          [{name, col} | fields] = tokens
          if length(tokens) != 6, do: source(row, col, "wrong field count")

          unless Regex.match?(~r/\A[a-z][a-z0-9_-]{0,15}\z/, name),
            do: source(row, col, "invalid name")

          sets =
            Enum.zip(fields, @fields)
            |> Enum.map(fn {{text, column}, {low, high, label}} ->
              case field(text, low, high) do
                nil -> source(row, column, "invalid #{label} field")
                set -> set
              end
            end)

          record = %{
            name: name,
            row: row,
            col: col,
            sets: sets,
            dom_star: elem(Enum.at(fields, 2), 0) == "*",
            dow_star: elem(Enum.at(fields, 4), 0) == "*"
          }

          {[record | records], count + 1}
        end
      end)

    records = Enum.reverse(records)

    Enum.reduce(records, MapSet.new(), fn record, names ->
      if MapSet.member?(names, record.name), do: source(record.row, record.col, "duplicate name")
      MapSet.put(names, record.name)
    end)

    records
  end

  defp ascii(<<>>, _row, _col), do: :ok

  defp ascii(<<byte, rest::binary>>, row, col) do
    if byte > 127, do: source(row, col, "expected ASCII")
    ascii(rest, row, col + 1)
  end

  defp source(row, col, message), do: fail("cron:#{row}:#{col}: #{message}")

  @doc "Parse a bounded decimal without constructing arbitrarily large integers."
  def number(text, max) do
    digits = String.trim_leading(text, "0")

    cond do
      digits == "" ->
        0

      byte_size(digits) > byte_size(Integer.to_string(max)) ->
        nil

      true ->
        n = String.to_integer(digits)
        if n <= max, do: n
    end
  end

  @doc "Return a selected value set, or nil for an invalid field."
  def field(text, low, high) do
    Enum.reduce_while(String.split(text, ","), MapSet.new(), fn term, set ->
      case term_values(term, low, high) do
        nil -> {:halt, nil}
        values -> {:cont, Enum.reduce(values, set, &MapSet.put(&2, &1))}
      end
    end)
  end

  defp term_values(term, low, high) do
    case Regex.run(~r/\A(\*|[0-9]+(?:-[0-9]+)?)(?:\/([0-9]+))?\z/, term) do
      nil ->
        nil

      captures ->
        base = Enum.at(captures, 1)
        step_text = Enum.at(captures, 2, "")
        step = if step_text == "", do: 1, else: number(step_text, high - low + 1)

        {first, last} =
          case String.split(base, "-") do
            ["*"] -> {low, high}
            [n] -> {number(n, high), if(step_text == "", do: number(n, high), else: high)}
            [a, b] -> {number(a, high), number(b, high)}
          end

        if is_integer(step) and step > 0 and is_integer(first) and is_integer(last) and
             first >= low and first <= last do
          Enum.to_list(first..last//step)
        end
    end
  end

  @doc "Find the earliest count matches strictly after an epoch minute."
  def runs(record, after_minute, count) do
    [minutes, hours, dom, months, dow] = record.sets
    minutes = Enum.sort(minutes)
    hours = Enum.sort(hours)
    limit = after_minute + @horizon

    found =
      Enum.reduce_while(div(after_minute, 1440)..div(limit, 1440), [], fn day, acc ->
        date = Date.add(@epoch, day)
        weekday = rem(Date.day_of_week(date), 7)
        dom_match = MapSet.member?(dom, date.day)
        dow_match = MapSet.member?(dow, weekday) or (weekday == 0 and MapSet.member?(dow, 7))

        day_match =
          case {record.dom_star, record.dow_star} do
            {true, true} -> true
            {true, false} -> dow_match
            {false, true} -> dom_match
            {false, false} -> dom_match or dow_match
          end

        acc =
          if MapSet.member?(months, date.month) and day_match do
            candidates =
              for hour <- hours,
                  minute <- minutes,
                  instant = day * 1440 + hour * 60 + minute,
                  instant > after_minute and instant <= limit,
                  do: instant

            Enum.reduce_while(candidates, acc, fn instant, runs ->
              next = [instant | runs]
              if length(next) == count, do: {:halt, next}, else: {:cont, next}
            end)
          else
            acc
          end

        if length(acc) == count, do: {:halt, acc}, else: {:cont, acc}
      end)

    if length(found) < count,
      do: source(record.row, 1, "not enough occurrences in search horizon")

    Enum.reverse(found)
  end
end
