defmodule Kogen.Core do
  @moduledoc "Cron command orchestration and argument validation."
  import Kogen.Input, only: [fail: 2]

  @help """
  Usage: kogen-cron [--after YYYY-MM-DDTHH:MM] [--count N] [--format text|json] [FILE|-]
  Find upcoming UTC minutes for named cron expressions.
  Options:
    --after VALUE    Exclusive UTC starting minute (default 2000-01-01T00:00).
    --count N        Occurrences per expression (default 3; range 1..20).
    --format FORMAT  Output text (default) or json.
    --help           Show this help.
  """

  def execute(["--help"]), do: @help

  def execute(args) do
    opts = arguments(args)
    bytes = Kogen.Input.read(opts.path, "cron")
    records = Kogen.Cron.parse(bytes)
    results = Enum.map(records, &{&1.name, Kogen.Cron.runs(&1, opts.after, opts.count)})
    render(results, opts.format)
  end

  def arguments(args) do
    scan(
      args,
      %{after: timestamp("2000-01-01T00:00"), count: 3, format: "text", path: nil},
      MapSet.new()
    )
  end

  defp scan([], opts, _seen), do: opts

  defp scan([option | rest], opts, seen) when option in ["--after", "--count", "--format"] do
    if MapSet.member?(seen, option), do: fail("cron: duplicate option '#{option}'", 2)

    case rest do
      [] ->
        fail("cron: option '#{option}' requires a value", 2)

      [value | tail] ->
        {key, parsed} = value(option, value)
        scan(tail, Map.put(opts, key, parsed), MapSet.put(seen, option))
    end
  end

  defp scan([token | rest], opts, seen) do
    cond do
      String.starts_with?(token, "-") and token != "-" ->
        fail("cron: unknown option '#{token}'", 2)

      opts.path != nil ->
        fail("cron: expected at most one input path", 2)

      true ->
        scan(rest, %{opts | path: token}, seen)
    end
  end

  defp value("--after", text) do
    case timestamp(text) do
      nil -> invalid("--after", text)
      minute -> {:after, minute}
    end
  end

  defp value("--count", text) do
    unless Regex.match?(~r/\A[0-9]+\z/, text), do: invalid("--count", text)

    case Kogen.Cron.number(text, 20) do
      n when is_integer(n) and n >= 1 -> {:count, n}
      _ -> fail("cron: value out of range for '--count': '#{text}'", 2)
    end
  end

  defp value("--format", text) when text in ["text", "json"], do: {:format, text}
  defp value("--format", text), do: invalid("--format", text)
  defp invalid(option, text), do: fail("cron: invalid value for '#{option}': '#{text}'", 2)

  defp timestamp(text) do
    if Regex.match?(~r/\A[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}\z/, text) do
      case NaiveDateTime.from_iso8601(text <> ":00") do
        {:ok, date} when date.year >= 1970 and date.year <= 2190 ->
          div(NaiveDateTime.diff(date, ~N[1970-01-01 00:00:00]), 60)

        _ ->
          nil
      end
    end
  end

  defp render(results, "text") do
    Enum.map_join(results, "", fn {name, runs} -> Enum.join([name | runs], "\t") <> "\n" end)
  end

  defp render(results, "json") do
    items =
      Enum.map_join(results, ",", fn {name, runs} ->
        "{\"name\":\"#{name}\",\"runs\":[#{Enum.join(runs, ",")}]}"
      end)

    "{\"schedules\":[#{items}]}\n"
  end
end
