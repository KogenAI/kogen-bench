defmodule Kogen.CronTest do
  use ExUnit.Case, async: true
  alias Kogen.Cron

  defp error(input, message) do
    assert_raise Kogen.Error, message, fn -> Cron.parse(input) end
  end

  test "field forms, bounds, leading zeroes and invalid terms" do
    assert Cron.field("1,3-7/2,1", 0, 59) == MapSet.new([1, 3, 5, 7])
    assert Cron.field("57/2", 0, 59) == MapSet.new([57, 59])
    assert Cron.field("*/12", 1, 12) == MapSet.new([1])
    assert Cron.field("00-02", 0, 59) == MapSet.new([0, 1, 2])

    for {low, high} <- [{0, 59}, {0, 23}, {1, 31}, {1, 12}, {0, 7}] do
      assert Cron.field("*", low, high) == MapSet.new(low..high)
      assert Cron.field("*/#{high - low + 1}", low, high) == MapSet.new([low])

      for bad <- [
            "",
            ",1",
            "1,",
            "1,,2",
            "-1",
            "+1",
            "1-",
            "2-1",
            "*/0",
            "*/#{high - low + 2}",
            "#{high + 1}",
            "1/",
            "1/2/3",
            "a",
            "999999999999999999999"
          ] do
        assert Cron.field(bad, low, high) == nil, bad
      end
    end

    assert Cron.field("0", 1, 31) == nil
  end

  test "physical input validation and error precedence" do
    assert Cron.parse(" \t # comment\r\n\t \n\r") == []
    error("bad\n" <> <<255>>, "cron:2:1: expected ASCII")
    error("# a\r\n " <> <<128>>, "cron:2:2: expected ASCII")
    error("job\tbad", "cron:1:4: tab is not allowed")
    error("  job *", "cron:1:3: wrong field count")
    error("  BAD * * * * *", "cron:1:3: invalid name")
    error("job * 3-1 * * *", "cron:1:7: invalid hour field")
    error("job * * * * *\njob * * * * *\nbad", "cron:3:1: wrong field count")
    error("job * * * * *\n  job * * * * *", "cron:2:3: duplicate name")
    assert length(Cron.parse("a123456789012345 * * * * *")) == 1
    error("a1234567890123456 * * * * *", "cron:1:1: invalid name")
  end

  test "byte and record limits precede grammar" do
    assert Cron.parse(String.duplicate(" ", 1_048_576)) == []
    error(String.duplicate(" ", 1_048_577), "cron: input too large")
    thousand = Enum.map_join(1..1000, "\n", &"job#{&1} * * * * *")
    assert length(Cron.parse(thousand)) == 1000
    error(thousand <> "\n# ignored\n\tbad", "cron:1002:1: too many schedules")
  end

  defp runs(fields, after_text, count) do
    [record] = Cron.parse("job " <> fields)
    Cron.runs(record, Kogen.Core.arguments(["--after", after_text]).after, count)
  end

  test "exclusive chronological matching, Sunday aliases and day OR" do
    assert runs("* * * * *", "1970-01-01T00:00", 2) == [1, 2]
    assert runs("1,3-7/2 * * * *", "1970-01-01T00:00", 3) == [1, 3, 5]
    assert runs("0 0 1 * 0", "1970-01-01T00:00", 3) == [4320, 14400, 24480]
    assert runs("0 0 * * 7", "1970-01-01T00:00", 1) == [4320]
    assert runs("0 0 */1 * 0", "1970-01-01T00:00", 2) == [1440, 2880]
    assert runs("0 0 * * 0,7", "1970-01-01T00:00", 2) == [4320, 14400]
  end

  test "the horizon includes its final minute but excludes the next minute" do
    # 2928 days after this start is 1978-01-07T00:01.
    # The first eight January 7ths have two matches; the last has only one.
    expected =
      for year <- 1970..1978,
          minute <- [1, 2],
          instant = Date.diff(Date.new!(year, 1, 7), ~D[1970-01-01]) * 1440 + minute,
          instant <= 8 * 366 * 1440 + 1,
          do: instant

    assert length(expected) == 17
    assert runs("1,2 0 7 1 *", "1970-01-01T00:01", 17) == expected

    assert_raise Kogen.Error, "cron:1:1: not enough occurrences in search horizon", fn ->
      runs("1,2 0 7 1 *", "1970-01-01T00:01", 18)
    end
  end

  test "Gregorian century and leap dates, supported upper bound and exhausted horizon" do
    opts = Kogen.Core.arguments(["--after", "2000-02-29T00:00"])
    assert runs("0 0 29 2 *", "2000-02-28T00:00", 1) == [opts.after]
    expected = Kogen.Core.arguments(["--after", "2104-02-29T00:00"]).after
    assert runs("0 0 29 2 *", "2096-03-01T00:00", 1) == [expected]
    latest = Kogen.Core.arguments(["--after", "2190-12-31T23:59"]).after
    assert runs("* * * * *", "2190-12-31T23:59", 1) == [latest + 1]

    assert_raise Kogen.Error, "cron:1:1: not enough occurrences in search horizon", fn ->
      runs("0 0 31 2 *", "1970-01-01T00:00", 1)
    end

    assert_raise Kogen.Error, "cron:1:1: not enough occurrences in search horizon", fn ->
      runs("0 0 29 2 *", "2096-03-01T00:00", 20)
    end
  end
end
